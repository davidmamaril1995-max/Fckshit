package com.example.ui.viewmodels

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.local.ProjectEntity
import com.example.data.local.SocialAccountEntity
import com.example.data.local.TrendTopicEntity
import com.example.data.remote.PublishResult
import com.example.data.repository.FacelessRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

sealed interface ScriptGenerationState {
    object Idle : ScriptGenerationState
    object Loading : ScriptGenerationState
    data class Success(
        val hookText: String,
        val scriptBody: String,
        val ctaText: String
    ) : ScriptGenerationState
    data class Error(val message: String) : ScriptGenerationState
}

sealed interface PublishState {
    object Idle : PublishState
    object Publishing : PublishState
    data class Success(val results: List<PublishResult>) : PublishState
    data class Error(val message: String) : PublishState
}

sealed interface AiAssistantState {
    object Idle : AiAssistantState
    object Loading : AiAssistantState
    data class Success(
        val titles: List<String>,
        val description: String,
        val hashtags: String,
        val captions: String,
        val bestTimes: String
    ) : AiAssistantState
    data class Error(val message: String) : AiAssistantState
}

class FacelessViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: FacelessRepository

    val selectedCategory = MutableStateFlow("All")

    val projects: StateFlow<List<ProjectEntity>>
    val archivedProjects: StateFlow<List<ProjectEntity>>
    val favoriteProjects: StateFlow<List<ProjectEntity>>
    val trends: StateFlow<List<TrendTopicEntity>>
    val socialAccounts: StateFlow<List<SocialAccountEntity>>
    val projectCount: StateFlow<Int>
    val totalViews: StateFlow<Long>

    val scriptState = MutableStateFlow<ScriptGenerationState>(ScriptGenerationState.Idle)
    val publishState = MutableStateFlow<PublishState>(PublishState.Idle)
    val aiAssistantState = MutableStateFlow<AiAssistantState>(AiAssistantState.Idle)

    init {
        val db = AppDatabase.getDatabase(application)
        repository = FacelessRepository(db)

        projects = repository.allProjects.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        archivedProjects = repository.archivedProjects.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        favoriteProjects = repository.favoriteProjects.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        trends = selectedCategory.flatMapLatest { cat ->
            if (cat == "All") repository.allTrends
            else repository.getTrendsByCategory(cat)
        }.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        socialAccounts = repository.allSocialAccounts.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        projectCount = repository.projectCount.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = 0
        )

        totalViews = repository.totalViews.map { it ?: 0L }.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = 0L
        )

        viewModelScope.launch {
            repository.seedInitialDataIfEmpty()
        }
    }

    fun setCategory(category: String) {
        selectedCategory.value = category
    }

    fun generateScript(topic: String, niche: String, format: String) {
        viewModelScope.launch {
            scriptState.value = ScriptGenerationState.Loading
            try {
                val rawText = repository.generateScriptWithAI(topic, niche, format)
                val hooks = parseHook(rawText)
                val body = parseBody(rawText)
                val cta = parseCta(rawText)
                scriptState.value = ScriptGenerationState.Success(
                    hookText = hooks,
                    scriptBody = body,
                    ctaText = cta
                )
            } catch (e: Exception) {
                scriptState.value = ScriptGenerationState.Error(e.message ?: "Failed to generate script")
            }
        }
    }

    fun resetScriptState() {
        scriptState.value = ScriptGenerationState.Idle
    }

    fun generateAiAssistantMetadata(topic: String) {
        viewModelScope.launch {
            aiAssistantState.value = AiAssistantState.Loading
            try {
                val titles = repository.generateTitlesWithAI(topic)
                val hashtags = repository.generateHashtagsWithAI(topic)
                val description = "Explore the deep galactic mysteries of $topic. Created with Intergalactic AI Studio."
                val captions = "✨ $topic ✨ Watch until the end for the cosmic twist!"
                val times = "Optimal Galactic Broadcast Times:\n• YouTube: 3:00 PM EST\n• TikTok: 7:00 PM EST\n• Instagram: 12:00 PM EST\n• X / Threads: 9:00 AM EST"

                aiAssistantState.value = AiAssistantState.Success(
                    titles = if (titles.isNotEmpty()) titles else listOf("10 Mind-Blowing Secrets of $topic", "The Hidden Truth Behind $topic", "Why $topic Is Changing Everything"),
                    description = description,
                    hashtags = hashtags.ifBlank { "#Intergalactic #AIContent #Viral #SpaceTech #Cosmos" },
                    captions = captions,
                    bestTimes = times
                )
            } catch (e: Exception) {
                aiAssistantState.value = AiAssistantState.Error(e.message ?: "AI Assistant error")
            }
        }
    }

    fun saveProject(
        title: String,
        niche: String,
        hook: String,
        body: String,
        cta: String,
        voiceoverStyle: String,
        format: String,
        visualStyle: String,
        platforms: List<String>,
        scheduledTime: Long,
        contentType: String = "Short Video",
        durationSeconds: Int = 45,
        workspace: String = "Main Workspace",
        folder: String = "General",
        campaign: String = "Default Campaign",
        timeZone: String = "UTC"
    ) {
        viewModelScope.launch {
            val status = if (scheduledTime > System.currentTimeMillis()) "Scheduled" else "Ready"
            val newProject = ProjectEntity(
                title = title.ifBlank { "Untitled Intergalactic Video" },
                nicheCategory = niche,
                hookText = hook,
                scriptBody = body,
                ctaText = cta,
                voiceoverStyle = voiceoverStyle,
                videoFormat = format,
                visualStyle = visualStyle,
                status = status,
                targetPlatforms = platforms.joinToString(","),
                scheduledTime = scheduledTime,
                updatedAt = System.currentTimeMillis(),
                contentType = contentType,
                durationSeconds = durationSeconds,
                workspace = workspace,
                folder = folder,
                campaign = campaign,
                timeZone = timeZone
            )
            repository.saveProject(newProject)
        }
    }

    fun updateProject(project: ProjectEntity) {
        viewModelScope.launch {
            repository.updateProject(project)
        }
    }

    fun duplicateProject(project: ProjectEntity) {
        viewModelScope.launch {
            val copy = project.copy(
                id = 0,
                title = "${project.title} (Copy)",
                createdAt = System.currentTimeMillis(),
                updatedAt = System.currentTimeMillis(),
                status = "Draft"
            )
            repository.saveProject(copy)
        }
    }

    fun deleteProject(id: Long) {
        viewModelScope.launch {
            repository.deleteProject(id)
        }
    }

    fun toggleFavorite(id: Long, isFavorite: Boolean) {
        viewModelScope.launch {
            repository.toggleFavorite(id, isFavorite)
        }
    }

    fun archiveProject(id: Long) {
        viewModelScope.launch {
            repository.toggleArchive(id, true)
        }
    }

    fun restoreProject(id: Long) {
        viewModelScope.launch {
            repository.toggleArchive(id, false)
        }
    }

    fun updateProjectOrganization(id: Long, workspace: String, folder: String, campaign: String) {
        viewModelScope.launch {
            repository.updateOrganization(id, workspace, folder, campaign)
        }
    }

    fun toggleTrendSaved(trend: TrendTopicEntity) {
        viewModelScope.launch {
            repository.toggleTrendSave(trend.id, !trend.isSaved)
        }
    }

    fun toggleSocialConnection(account: SocialAccountEntity) {
        viewModelScope.launch {
            repository.updateSocialConnection(account.platform, !account.isConnected)
        }
    }

    fun publishProjectNow(project: ProjectEntity) {
        viewModelScope.launch {
            publishState.value = PublishState.Publishing
            try {
                val results = repository.publishProject(project)
                publishState.value = PublishState.Success(results)
            } catch (e: Exception) {
                publishState.value = PublishState.Error(e.message ?: "Publishing failed")
            }
        }
    }

    fun resetPublishState() {
        publishState.value = PublishState.Idle
    }

    private fun parseHook(text: String): String {
        return if (text.contains("[HOOK")) {
            text.substringAfter("[HOOK").substringBefore("[BODY").trim()
        } else {
            text.take(120)
        }
    }

    private fun parseBody(text: String): String {
        return if (text.contains("[BODY NARRATION]:")) {
            text.substringAfter("[BODY NARRATION]:").substringBefore("[CALL TO ACTION]:").trim()
        } else {
            text
        }
    }

    private fun parseCta(text: String): String {
        return if (text.contains("[CALL TO ACTION]:")) {
            text.substringAfter("[CALL TO ACTION]:").trim()
        } else {
            "Follow Intergalactic Studio for more viral space tech content!"
        }
    }
}
