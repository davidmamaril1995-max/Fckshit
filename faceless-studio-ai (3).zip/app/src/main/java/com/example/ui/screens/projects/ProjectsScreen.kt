package com.example.ui.screens.projects

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.ProjectEntity
import com.example.ui.theme.*
import com.example.ui.viewmodels.FacelessViewModel
import com.example.ui.viewmodels.PublishState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProjectsScreen(
    viewModel: FacelessViewModel
) {
    val projects by viewModel.projects.collectAsStateWithLifecycle()
    val archivedProjects by viewModel.archivedProjects.collectAsStateWithLifecycle()

    var selectedWorkspace by remember { mutableStateOf("All Workspaces") }
    var selectedFolder by remember { mutableStateOf("All Folders") }
    var showArchivedTab by remember { mutableStateOf(false) }

    var selectedProjectForMove by remember { mutableStateOf<ProjectEntity?>(null) }
    var selectedProjectForDetail by remember { mutableStateOf<ProjectEntity?>(null) }
    val publishState by viewModel.publishState.collectAsStateWithLifecycle()

    val workspacesList = listOf("All Workspaces", "Main Workspace", "Creator Hub", "Client Orbit")
    val foldersList = listOf("All Folders", "Tech Viral", "Cosmic Horror", "Monetization", "General")

    val activeList = if (showArchivedTab) archivedProjects else projects
    val filteredProjects = activeList.filter { project ->
        val matchWs = selectedWorkspace == "All Workspaces" || project.workspace.equals(selectedWorkspace, ignoreCase = true)
        val matchFld = selectedFolder == "All Folders" || project.folder.equals(selectedFolder, ignoreCase = true)
        matchWs && matchFld
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Default.FolderSpecial, contentDescription = null, tint = NebulaPurple, modifier = Modifier.size(24.dp))
                        Text(
                            text = "Workspaces & Campaigns",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = TextPrimary
                        )
                    }
                },
                actions = {
                    IconButton(onClick = { showArchivedTab = !showArchivedTab }) {
                        Icon(
                            imageVector = if (showArchivedTab) Icons.Default.Unarchive else Icons.Default.Archive,
                            contentDescription = "Toggle Archived",
                            tint = if (showArchivedTab) StarGold else TextSecondary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = StudioDarkBackground)
            )
        },
        containerColor = StudioDarkBackground
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Workspace Selector Row
            Text("Workspaces Hierarchy:", fontSize = 12.sp, color = TextSecondary)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(workspacesList) { ws ->
                    val isSel = selectedWorkspace == ws
                    FilterChip(
                        selected = isSel,
                        onClick = { selectedWorkspace = ws },
                        label = { Text(ws) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = PurpleContainer,
                            selectedLabelColor = OnPurpleContainer
                        )
                    )
                }
            }

            // Folder Selector Row
            Text("Folder Categories:", fontSize = 12.sp, color = TextSecondary)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(foldersList) { fld ->
                    val isSel = selectedFolder == fld
                    FilterChip(
                        selected = isSel,
                        onClick = { selectedFolder = fld },
                        label = { Text(fld) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = CyanContainer,
                            selectedLabelColor = OnCyanContainer
                        )
                    )
                }
            }

            // Projects List
            if (filteredProjects.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(30.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Default.FolderOpen, contentDescription = null, tint = TextMuted, modifier = Modifier.size(48.dp))
                        Text(
                            text = if (showArchivedTab) "No archived projects found" else "No missions found in this Workspace/Folder",
                            color = TextSecondary,
                            fontSize = 14.sp
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(filteredProjects) { project ->
                        OrganizedProjectCard(
                            project = project,
                            isArchived = showArchivedTab,
                            onClick = { selectedProjectForDetail = project },
                            onMove = { selectedProjectForMove = project },
                            onArchive = { viewModel.archiveProject(project.id) },
                            onRestore = { viewModel.restoreProject(project.id) },
                            onDelete = { viewModel.deleteProject(project.id) }
                        )
                    }

                    item { Spacer(modifier = Modifier.height(20.dp)) }
                }
            }
        }
    }

    // Move Workspace / Folder Modal
    selectedProjectForMove?.let { project ->
        MoveProjectDialog(
            project = project,
            onDismiss = { selectedProjectForMove = null },
            onMoveConfirm = { ws, fld, cmp ->
                viewModel.updateProjectOrganization(project.id, ws, fld, cmp)
                selectedProjectForMove = null
            }
        )
    }

    // Detail Modal
    selectedProjectForDetail?.let { project ->
        AlertDialog(
            onDismissRequest = {
                selectedProjectForDetail = null
                viewModel.resetPublishState()
            },
            title = { Text(project.title, color = TextPrimary) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Workspace: ${project.workspace} • Folder: ${project.folder}", fontSize = 12.sp, color = CosmicCyan)
                    Text("Campaign: ${project.campaign}", fontSize = 12.sp, color = StarGold)
                    HorizontalDivider(color = StudioBorder)
                    Text("Hook: ${project.hookText}", fontSize = 12.sp, color = TextSecondary)
                    Text("Script: ${project.scriptBody}", fontSize = 12.sp, color = TextSecondary)
                }
            },
            confirmButton = {
                Button(
                    onClick = { viewModel.publishProjectNow(project) },
                    colors = ButtonDefaults.buttonColors(containerColor = NebulaPurple)
                ) {
                    Text("Broadcast Now", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { selectedProjectForDetail = null }) {
                    Text("Close", color = TextSecondary)
                }
            },
            containerColor = StudioDarkSurface
        )
    }
}

@Composable
private fun OrganizedProjectCard(
    project: ProjectEntity,
    isArchived: Boolean,
    onClick: () -> Unit,
    onMove: () -> Unit,
    onArchive: () -> Unit,
    onRestore: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("org_project_card_${project.id}"),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = StudioDarkSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, StudioBorder)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = PurpleContainer
                ) {
                    Text(
                        text = "${project.workspace} / ${project.folder}",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = OnPurpleContainer,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }

                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = when (project.status.lowercase()) {
                        "published" -> CyanContainer
                        "scheduled" -> GoldContainer
                        else -> StudioDarkSurfaceVariant
                    }
                ) {
                    Text(
                        text = project.status,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = when (project.status.lowercase()) {
                            "published" -> OnCyanContainer
                            "scheduled" -> OnGoldContainer
                            else -> TextSecondary
                        },
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Text(
                text = project.title,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )

            Text(
                text = "Campaign: ${project.campaign} • Format: ${project.videoFormat}",
                fontSize = 11.sp,
                color = TextMuted
            )

            HorizontalDivider(color = StudioBorder)

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onMove) {
                    Icon(Icons.Default.DriveFileMove, contentDescription = "Move", tint = CosmicCyan)
                }

                Row {
                    if (isArchived) {
                        IconButton(onClick = onRestore) {
                            Icon(Icons.Default.Restore, contentDescription = "Restore", tint = StatusGreen)
                        }
                    } else {
                        IconButton(onClick = onArchive) {
                            Icon(Icons.Default.Archive, contentDescription = "Archive", tint = StarGold)
                        }
                    }
                    IconButton(onClick = onDelete) {
                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = StatusRed)
                    }
                }
            }
        }
    }
}

@Composable
private fun MoveProjectDialog(
    project: ProjectEntity,
    onDismiss: () -> Unit,
    onMoveConfirm: (String, String, String) -> Unit
) {
    var workspaceInput by remember { mutableStateOf(project.workspace) }
    var folderInput by remember { mutableStateOf(project.folder) }
    var campaignInput by remember { mutableStateOf(project.campaign) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Move Project Organization", color = TextPrimary) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = workspaceInput,
                    onValueChange = { workspaceInput = it },
                    label = { Text("Target Workspace") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = folderInput,
                    onValueChange = { folderInput = it },
                    label = { Text("Target Folder") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = campaignInput,
                    onValueChange = { campaignInput = it },
                    label = { Text("Target Campaign") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onMoveConfirm(workspaceInput, folderInput, campaignInput) },
                colors = ButtonDefaults.buttonColors(containerColor = CosmicCyan)
            ) {
                Text("Confirm Move", color = StudioDarkBackground, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = TextSecondary)
            }
        },
        containerColor = StudioDarkSurface
    )
}
