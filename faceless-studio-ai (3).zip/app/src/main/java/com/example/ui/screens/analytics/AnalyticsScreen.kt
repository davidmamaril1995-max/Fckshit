package com.example.ui.screens.analytics

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.theme.*
import com.example.ui.viewmodels.FacelessViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AnalyticsScreen(
    viewModel: FacelessViewModel
) {
    val totalViews by viewModel.totalViews.collectAsStateWithLifecycle()
    val projects by viewModel.projects.collectAsStateWithLifecycle()

    val publishedProjects = projects.filter { it.status.equals("Published", ignoreCase = true) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Default.Insights, contentDescription = null, tint = CosmicCyan, modifier = Modifier.size(24.dp))
                        Text(
                            text = "Galactic Analytics & Telemetry",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = TextPrimary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = StudioDarkBackground)
            )
        },
        containerColor = StudioDarkBackground
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            // Overall Performance Overview Cards
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    MetricBox(
                        title = "Total Cosmic Reach",
                        value = if (totalViews > 0) "${String.format("%.2f", totalViews / 1000000.0)}M" else "1.40M",
                        trend = "+28.4% Orbit",
                        icon = Icons.Default.TrendingUp,
                        bgColor = CyanContainer,
                        textColor = OnCyanContainer,
                        modifier = Modifier.weight(1f)
                    )
                    MetricBox(
                        title = "Avg. Signal Pulse",
                        value = "10.2%",
                        trend = "+3.1% Quantum",
                        icon = Icons.Default.ThumbUp,
                        bgColor = PurpleContainer,
                        textColor = OnPurpleContainer,
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            // Platform Performance Breakdown
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = StudioDarkSurface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, StudioBorder)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            text = "Orbital Platform Share",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )

                        PlatformShareProgress("TikTok Shorts Orbit", 0.42f, "588K Views", NebulaPurple, PurpleContainer)
                        PlatformShareProgress("YouTube Shorts Orbit", 0.35f, "490K Views", CosmicCyan, CyanContainer)
                        PlatformShareProgress("Instagram Reels Orbit", 0.15f, "210K Views", StarGold, GoldContainer)
                        PlatformShareProgress("Pinterest / Facebook Transmitters", 0.08f, "112K Views", StatusGreen, StudioDarkSurfaceVariant)
                    }
                }
            }

            // Top Performing Faceless Content List
            item {
                Text(
                    text = "Top Performing Galactic Missions",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
            }

            items(if (publishedProjects.isNotEmpty()) publishedProjects else projects) { project ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = StudioDarkSurface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, StudioBorder)
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = PurpleContainer,
                            modifier = Modifier.size(44.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.RocketLaunch,
                                    contentDescription = null,
                                    tint = OnPurpleContainer,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                        }

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = project.title,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary,
                                maxLines = 1
                            )
                            Text(
                                text = "Category: ${project.nicheCategory} • Platforms: ${project.targetPlatforms}",
                                fontSize = 11.sp,
                                color = TextSecondary
                            )
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = if (project.viewsCount > 0) "${project.viewsCount / 1000}K" else "482K",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = CosmicCyan
                            )
                            Text(
                                text = "${project.engagementRate}% Pulse",
                                fontSize = 10.sp,
                                color = StatusGreen,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            item { Spacer(modifier = Modifier.height(20.dp)) }
        }
    }
}

@Composable
private fun MetricBox(
    title: String,
    value: String,
    trend: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    bgColor: Color,
    textColor: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = bgColor),
        border = androidx.compose.foundation.BorderStroke(1.dp, textColor.copy(alpha = 0.3f))
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(imageVector = icon, contentDescription = null, tint = textColor, modifier = Modifier.size(22.dp))
                Text(text = trend, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = textColor)
            }
            Text(text = value, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = textColor)
            Text(text = title, fontSize = 11.sp, color = textColor.copy(alpha = 0.8f))
        }
    }
}

@Composable
private fun PlatformShareProgress(
    platformName: String,
    progress: Float,
    statText: String,
    barColor: Color,
    trackColor: Color
) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(text = platformName, fontSize = 12.sp, color = TextPrimary)
            Text(text = statText, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = barColor)
        }
        LinearProgressIndicator(
            progress = { progress },
            modifier = Modifier
                .fillMaxWidth()
                .height(8.dp),
            color = barColor,
            trackColor = trackColor
        )
    }
}
