package com.example.ui.screens.social

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.SocialAccountEntity
import com.example.ui.theme.*
import com.example.ui.viewmodels.FacelessViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SocialCommandScreen(
    viewModel: FacelessViewModel
) {
    val socialAccounts by viewModel.socialAccounts.collectAsStateWithLifecycle()

    var selectedTab by remember { mutableIntStateOf(0) } // 0 = Command Center, 1 = Accounts, 2 = Bulk Publishing, 3 = Social Inbox
    var selectedInboxFilter by remember { mutableStateOf("All") } // All, Comments, Messages, System Alerts
    var replyText by remember { mutableStateOf("") }
    var actionStatusMessage by remember { mutableStateOf("") }

    val allPlatforms = listOf("YouTube", "TikTok", "Facebook", "Instagram", "Threads", "Pinterest", "X")

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Default.Hub, contentDescription = null, tint = CosmicCyan, modifier = Modifier.size(24.dp))
                        Text(
                            text = "Social Command Center",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = TextPrimary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = StudioDarkBackground)
            )
        },
        containerColor = StudioDarkBackground
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Main Section Tabs
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = StudioDarkSurface,
                contentColor = CosmicCyan,
                divider = { HorizontalDivider(color = StudioBorder) }
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("Dashboard", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text("Accounts (7)", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                )
                Tab(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    text = { Text("Bulk Publish", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                )
                Tab(
                    selected = selectedTab == 3,
                    onClick = { selectedTab = 3 },
                    text = { Text("Inbox (14)", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                )
            }

            // Tab Content Router
            when (selectedTab) {
                0 -> DashboardSection(socialAccounts = socialAccounts)
                1 -> AccountsManagementSection(
                    allPlatforms = allPlatforms,
                    connectedAccounts = socialAccounts,
                    onToggleConnection = { viewModel.toggleSocialConnection(it) }
                )
                2 -> BulkPublishingSection(
                    connectedAccounts = socialAccounts,
                    onPublishTriggered = { msg -> actionStatusMessage = msg }
                )
                3 -> SocialInboxSection(
                    selectedFilter = selectedInboxFilter,
                    onFilterChange = { selectedInboxFilter = it },
                    replyText = replyText,
                    onReplyTextChange = { replyText = it },
                    onSendReply = {
                        actionStatusMessage = "Reply sent successfully across transmitter channel!"
                        replyText = ""
                    }
                )
            }

            if (actionStatusMessage.isNotEmpty()) {
                Snackbar(
                    action = {
                        TextButton(onClick = { actionStatusMessage = "" }) {
                            Text("OK", color = CosmicCyan)
                        }
                    },
                    containerColor = StudioDarkSurface
                ) {
                    Text(actionStatusMessage, color = StatusGreen)
                }
            }
        }
    }
}

@Composable
private fun DashboardSection(
    socialAccounts: List<SocialAccountEntity>
) {
    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(16.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        // High Level Metrics
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                MetricCard(
                    title = "Combined Followers",
                    value = "939.8K",
                    subtitle = "Across 7 Transmitters",
                    icon = Icons.Default.Groups,
                    color = NebulaPurple,
                    modifier = Modifier.weight(1f)
                )
                MetricCard(
                    title = "30-Day Total Reach",
                    value = "6.48M",
                    subtitle = "+34.2% Growth",
                    icon = Icons.Default.Public,
                    color = CosmicCyan,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                MetricCard(
                    title = "Avg. Engagement",
                    value = "10.4%",
                    subtitle = "High Conversion",
                    icon = Icons.Default.ThumbUp,
                    color = StarGold,
                    modifier = Modifier.weight(1f)
                )
                MetricCard(
                    title = "Connected Transmitters",
                    value = "${socialAccounts.count { it.isConnected }}/7",
                    subtitle = "Active Channel Sync",
                    icon = Icons.Default.CellTower,
                    color = StatusGreen,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Platform Health Breakdown
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = StudioDarkSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, StudioBorder)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text("Orbit Transmitters Status Overview", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                    HorizontalDivider(color = StudioBorder)

                    socialAccounts.forEach { acc ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(10.dp)
                                        .clip(CircleShape)
                                        .background(if (acc.isConnected) StatusGreen else StatusRed)
                                )
                                Column {
                                    Text(acc.platform, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                                    Text(acc.accountHandle, fontSize = 11.sp, color = TextSecondary)
                                }
                            }

                            Column(horizontalAlignment = Alignment.End) {
                                Text("${acc.followerCount} Followers", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = CosmicCyan)
                                Text("Reach: ${acc.reachCount}", fontSize = 10.sp, color = TextMuted)
                            }
                        }
                    }
                }
            }
        }

        item { Spacer(modifier = Modifier.height(20.dp)) }
    }
}

@Composable
private fun AccountsManagementSection(
    allPlatforms: List<String>,
    connectedAccounts: List<SocialAccountEntity>,
    onToggleConnection: (SocialAccountEntity) -> Unit
) {
    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        items(allPlatforms) { platform ->
            val account = connectedAccounts.find { it.platform.equals(platform, ignoreCase = true) }
                ?: SocialAccountEntity(platform, "@${platform.lowercase()}_creator", false)

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("account_card_$platform"),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = StudioDarkSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, StudioBorder)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = if (account.isConnected) PurpleContainer else StudioDarkSurfaceVariant,
                            modifier = Modifier.size(44.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = when (platform) {
                                        "YouTube" -> Icons.Default.SmartDisplay
                                        "TikTok" -> Icons.Default.MusicNote
                                        "Instagram" -> Icons.Default.CameraAlt
                                        "Facebook" -> Icons.Default.Share
                                        "Threads" -> Icons.Default.AlternateEmail
                                        "Pinterest" -> Icons.Default.PushPin
                                        else -> Icons.Default.Tag
                                    },
                                    contentDescription = null,
                                    tint = if (account.isConnected) CosmicCyan else TextMuted
                                )
                            }
                        }

                        Column {
                            Text(text = platform, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                            Text(
                                text = if (account.isConnected) "${account.accountHandle} • ${account.followerCount} Followers" else "Transmitter Offline",
                                fontSize = 11.sp,
                                color = if (account.isConnected) CosmicCyan else TextMuted
                            )
                        }
                    }

                    Button(
                        onClick = { onToggleConnection(account) },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (account.isConnected) StatusRed.copy(alpha = 0.2f) else NebulaPurple
                        )
                    ) {
                        Text(
                            text = if (account.isConnected) "Disconnect" else "Connect",
                            color = if (account.isConnected) StatusRed else Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }

        item { Spacer(modifier = Modifier.height(20.dp)) }
    }
}

@Composable
private fun BulkPublishingSection(
    connectedAccounts: List<SocialAccountEntity>,
    onPublishTriggered: (String) -> Unit
) {
    val selectedPlatforms = remember { mutableStateListOf<String>().apply { addAll(connectedAccounts.map { it.platform }) } }
    var bulkMessageInput by remember { mutableStateOf("") }

    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(14.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = StudioDarkSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, StudioBorder)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text("Cross-Platform Multi-Transmitter Broadcast", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = NebulaPurple)
                    HorizontalDivider(color = StudioBorder)

                    Text("1. Target Transmitter Channels:", fontSize = 12.sp, color = TextSecondary)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(connectedAccounts) { acc ->
                            val isChecked = selectedPlatforms.contains(acc.platform)
                            FilterChip(
                                selected = isChecked,
                                onClick = {
                                    if (isChecked) selectedPlatforms.remove(acc.platform)
                                    else selectedPlatforms.add(acc.platform)
                                },
                                leadingIcon = {
                                    if (isChecked) Icon(Icons.Default.Check, contentDescription = null, tint = OnPurpleContainer, modifier = Modifier.size(16.dp))
                                },
                                label = { Text(acc.platform) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = PurpleContainer,
                                    selectedLabelColor = OnPurpleContainer
                                )
                            )
                        }
                    }

                    Text("2. Broadcast Payload Content:", fontSize = 12.sp, color = TextSecondary)
                    OutlinedTextField(
                        value = bulkMessageInput,
                        onValueChange = { bulkMessageInput = it },
                        placeholder = { Text("Enter post text or viral announcement to post to all selected channels...") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(110.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = StudioDarkSurfaceVariant,
                            unfocusedContainerColor = StudioDarkSurfaceVariant,
                            focusedBorderColor = CosmicCyan,
                            unfocusedBorderColor = StudioBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        )
                    )

                    Button(
                        onClick = {
                            if (bulkMessageInput.isNotBlank()) {
                                onPublishTriggered("Bulk Broadcast initiated across ${selectedPlatforms.size} platforms!")
                                bulkMessageInput = ""
                            }
                        },
                        enabled = bulkMessageInput.isNotBlank() && selectedPlatforms.isNotEmpty(),
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = CosmicCyan)
                    ) {
                        Icon(Icons.Default.Send, contentDescription = null, tint = StudioDarkBackground)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Broadcast To Selected Channels", color = StudioDarkBackground, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun SocialInboxSection(
    selectedFilter: String,
    onFilterChange: (String) -> Unit,
    replyText: String,
    onReplyTextChange: (String) -> Unit,
    onSendReply: () -> Unit
) {
    val sampleInboxItems = listOf(
        InboxItem("1", "TikTok", "@tech_lover22", "Comment", "Which AI tool did you use for the 3D voiceover?", "10m ago"),
        InboxItem("2", "YouTube", "SciFi Explorer", "Comment", "Mind blown! Subscribed to the channel immediately.", "25m ago"),
        InboxItem("3", "Instagram", "@creator_pro", "Message", "Hey! Loved your faceless reels. Are you open to a channel collab?", "1h ago"),
        InboxItem("4", "X", "@space_geek", "Notification", "Retweeted your post on Quantum Computing 2026", "2h ago")
    )

    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("All", "Comments", "Messages", "Notifications").forEach { filter ->
                    val isSelected = selectedFilter == filter
                    FilterChip(
                        selected = isSelected,
                        onClick = { onFilterChange(filter) },
                        label = { Text(filter) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = PurpleContainer,
                            selectedLabelColor = OnPurpleContainer
                        )
                    )
                }
            }
        }

        items(sampleInboxItems) { item ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = StudioDarkSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, StudioBorder)
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = CyanContainer
                        ) {
                            Text(
                                text = "${item.platform} • ${item.type}",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = OnCyanContainer,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }

                        Text(item.timeAgo, fontSize = 10.sp, color = TextMuted)
                    }

                    Text(item.author, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                    Text(item.body, fontSize = 12.sp, color = TextSecondary)

                    // Reply Interface
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = replyText,
                            onValueChange = onReplyTextChange,
                            placeholder = { Text("Send quick reply...", fontSize = 11.sp) },
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp),
                            shape = RoundedCornerShape(10.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = StudioDarkSurfaceVariant,
                                unfocusedContainerColor = StudioDarkSurfaceVariant
                            )
                        )
                        IconButton(
                            onClick = onSendReply,
                            modifier = Modifier.background(NebulaPurple, CircleShape)
                        ) {
                            Icon(Icons.Default.Send, contentDescription = "Send", tint = Color.White, modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }
        }

        item { Spacer(modifier = Modifier.height(20.dp)) }
    }
}

private data class InboxItem(
    val id: String,
    val platform: String,
    val author: String,
    val type: String,
    val body: String,
    val timeAgo: String
)

@Composable
private fun MetricCard(
    title: String,
    value: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = StudioDarkSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, StudioBorder)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Icon(imageVector = icon, contentDescription = null, tint = color, modifier = Modifier.size(24.dp))
            Text(value, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, color = TextPrimary)
            Text(title, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = color)
            Text(subtitle, fontSize = 10.sp, color = TextMuted)
        }
    }
}
