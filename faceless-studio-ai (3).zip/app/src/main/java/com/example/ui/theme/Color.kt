package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Galactic Dark Theme Canvas
val StudioDarkBackground = Color(0xFF080C17)       // Deep space dark void canvas
val StudioDarkSurface = Color(0xFF10172A)          // Dark galaxy card container
val StudioDarkSurfaceVariant = Color(0xFF1A233A)   // Glassmorphic panel variant
val StudioBorder = Color(0xFF2E3D60)               // Cosmic blue border stroke

// Core Galactic Brand Colors
val PrimaryBlue = Color(0xFF1D4ED8)                // Deep Space Blue
val PrimaryBlueLight = Color(0xFF60A5FA)           // Bright Stellar Blue
val NebulaPurple = Color(0xFF8B5CF6)               // Vibrant Nebula Purple
val NebulaPurpleLight = Color(0xFFC084FC)          // Soft Purple accent
val NebulaPurpleDark = Color(0xFF4C1D95)           // Deep Purple gradient tone
val CosmicCyan = Color(0xFF06B6D4)                 // Cosmic Cyan
val CosmicCyanLight = Color(0xFF67E8F9)            // Bright Cyan glow
val StarGold = Color(0xFFF59E0B)                   // Star Gold highlight
val StarGoldLight = Color(0xFFFDE047)               // Bright Gold glow

// Surface Containers
val PurpleContainer = Color(0xFF2E1B4E)
val OnPurpleContainer = Color(0xFFE9D5FF)

val BlueContainer = Color(0xFF1E293B)
val OnBlueContainer = Color(0xFF93C5FD)

val CyanContainer = Color(0xFF0C2E3A)
val OnCyanContainer = Color(0xFFA5F3FC)

val GoldContainer = Color(0xFF332305)
val OnGoldContainer = Color(0xFFFDE68A)

// Status Indicators
val StatusGreen = Color(0xFF10B981)                // Quantum Green online
val StatusRed = Color(0xFFEF4444)                  // Solar Flare Warning

// Futuristic High-Contrast Text
val TextPrimary = Color(0xFFF8FAFC)                // Pure white stellar text
val TextSecondary = Color(0xFF94A3B8)              // Slate space secondary text
val TextMuted = Color(0xFF64748B)                  // Muted galaxy text
