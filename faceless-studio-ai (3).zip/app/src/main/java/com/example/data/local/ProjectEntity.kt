package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "projects")
data class ProjectEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val nicheCategory: String,
    val hookText: String,
    val scriptBody: String,
    val ctaText: String,
    val voiceoverStyle: String,
    val videoFormat: String = "9:16", // "9:16", "16:9", "1:1"
    val visualStyle: String = "Cyberpunk 3D",
    val thumbnailPrompt: String = "",
    val thumbnailUri: String = "",
    val status: String = "Draft", // Draft, Rendering, Ready, Scheduled, Published
    val targetPlatforms: String = "YouTube,TikTok,Instagram,Facebook,Threads,Pinterest,X",
    val scheduledTime: Long = 0L,
    val viewsCount: Long = 0L,
    val engagementRate: Float = 0f,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val contentType: String = "Short Video", // Long Video, Short Video, Reel, Post, Carousel
    val durationSeconds: Int = 45,
    val isFavorite: Boolean = false,
    val isArchived: Boolean = false,
    val workspace: String = "Main Workspace",
    val folder: String = "General",
    val campaign: String = "Default Campaign",
    val videoUrl: String = "",
    val timeZone: String = "UTC",
    val description: String = "",
    val hashtags: String = "#Intergalactic #AIVideo #Viral"
)
