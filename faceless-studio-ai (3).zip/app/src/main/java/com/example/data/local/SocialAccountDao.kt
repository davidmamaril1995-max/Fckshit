package com.example.data.local

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface SocialAccountDao {
    @Query("SELECT * FROM social_accounts")
    fun getAllAccounts(): Flow<List<SocialAccountEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateAccount(account: SocialAccountEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAccounts(accounts: List<SocialAccountEntity>)

    @Query("UPDATE social_accounts SET isConnected = :isConnected WHERE platform = :platform")
    suspend fun updateConnectionStatus(platform: String, isConnected: Boolean)
}
