package com.example.data.repository

import com.example.data.auth.OAuthManager
import com.example.data.auth.SessionManager
import com.example.data.auth.TokenManager
import com.example.data.local.SocialAccountDao
import com.example.data.local.SocialAccountEntity
import kotlinx.coroutines.flow.Flow

class SocialAccountRepository(
    private val socialDao: SocialAccountDao,
    private val tokenManager: TokenManager,
    private val sessionManager: SessionManager,
    private val oAuthManager: OAuthManager
) {

    fun getAllAccounts(): Flow<List<SocialAccountEntity>> = socialDao.getAllAccounts()

    fun getAccountsForPlatform(platform: String): Flow<List<SocialAccountEntity>> =
        socialDao.getAccountsForPlatform(platform)

    suspend fun getActiveAccountForPlatform(platform: String): SocialAccountEntity? =
        socialDao.getActiveAccountForPlatform(platform)

    suspend fun connectNewAccountViaOAuth(
        platform: String,
        accountHandle: String
    ): SocialAccountEntity {
        val authResult = oAuthManager.initiateOAuthFlow(platform, accountHandle)

        val newAccount = SocialAccountEntity(
            platform = platform,
            accountName = authResult.accountName,
            accountHandle = authResult.accountHandle,
            isConnected = true,
            isActiveTarget = true,
            accessToken = authResult.accessToken,
            refreshToken = authResult.refreshToken,
            tokenExpiry = System.currentTimeMillis() + (authResult.expiresInSeconds * 1000L),
            oauthScopes = authResult.scopes,
            hasPublishingPermission = true,
            hasSchedulingPermission = true,
            hasAnalyticsPermission = true,
            lastSyncTime = System.currentTimeMillis()
        )

        val generatedId = socialDao.insertOrUpdateAccount(newAccount)

        // Save tokens securely in TokenManager & set active in SessionManager
        tokenManager.saveTokens(generatedId, authResult.accessToken, authResult.refreshToken, authResult.expiresInSeconds)
        sessionManager.setActiveAccountId(platform, generatedId)
        socialDao.setActiveTargetAccount(platform, generatedId)

        return newAccount.copy(id = generatedId)
    }

    suspend fun switchActiveAccount(platform: String, accountId: Long) {
        socialDao.setActiveTargetAccount(platform, accountId)
        sessionManager.setActiveAccountId(platform, accountId)
    }

    suspend fun disconnectAccount(accountId: Long) {
        tokenManager.clearTokens(accountId)
        socialDao.updateConnectionStatus(accountId, false)
    }

    suspend fun refreshToken(account: SocialAccountEntity): SocialAccountEntity {
        val newAccessToken = oAuthManager.refreshToken(account.platform, account.refreshToken)
        val newExpiry = System.currentTimeMillis() + (2592000L * 1000L)

        tokenManager.saveTokens(account.id, newAccessToken, account.refreshToken, 2592000L)
        
        val updated = account.copy(
            accessToken = newAccessToken,
            tokenExpiry = newExpiry,
            lastSyncTime = System.currentTimeMillis()
        )
        socialDao.insertOrUpdateAccount(updated)
        return updated
    }

    suspend fun updatePermissions(
        accountId: Long,
        publishing: Boolean,
        scheduling: Boolean,
        analytics: Boolean
    ) {
        val existing = socialDao.getAccountById(accountId) ?: return
        val updated = existing.copy(
            hasPublishingPermission = publishing,
            hasSchedulingPermission = scheduling,
            hasAnalyticsPermission = analytics
        )
        socialDao.insertOrUpdateAccount(updated)
    }
}
