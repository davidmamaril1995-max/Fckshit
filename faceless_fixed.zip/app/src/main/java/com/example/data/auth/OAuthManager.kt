package com.example.data.auth

import kotlinx.coroutines.delay
import java.util.UUID

data class OAuthResult(
    val isSuccess: Boolean,
    val platform: String,
    val accountName: String,
    val accountHandle: String,
    val accessToken: String,
    val refreshToken: String,
    val expiresInSeconds: Long,
    val scopes: String,
    val errorMessage: String? = null
)

class OAuthManager(
    private val tokenManager: TokenManager
) {

    private val platformScopes = mapOf(
        "YouTube" to "https://www.googleapis.com/auth/youtube.upload,https://www.googleapis.com/auth/youtube.readonly",
        "TikTok" to "user.info.basic,video.upload,video.publish",
        "Facebook" to "pages_manage_posts,pages_read_engagement,instagram_basic",
        "Instagram" to "instagram_basic,instagram_content_publish",
        "Threads" to "threads_basic,threads_content_publish",
        "Pinterest" to "boards:read,pins:read,pins:write",
        "X" to "tweet.read,tweet.write,users.read,offline.access"
    )

    suspend fun initiateOAuthFlow(
        platform: String,
        accountHandle: String
    ): OAuthResult {
        // Simulate OAuth network authorization delay
        delay(1200)

        val cleanHandle = if (accountHandle.startsWith("@")) accountHandle else "@$accountHandle"
        val scopes = platformScopes[platform] ?: "profile,publish_content,scheduling,analytics"
        val accessToken = "oauth_access_${platform.lowercase()}_${UUID.randomUUID().toString().take(8)}"
        val refreshToken = "oauth_refresh_${platform.lowercase()}_${UUID.randomUUID().toString().take(8)}"
        val accountName = "$platform Official Channel"

        return OAuthResult(
            isSuccess = true,
            platform = platform,
            accountName = accountName,
            accountHandle = cleanHandle,
            accessToken = accessToken,
            refreshToken = refreshToken,
            expiresInSeconds = 2592000L, // 30 days
            scopes = scopes
        )
    }

    suspend fun refreshToken(platform: String, oldRefreshToken: String): String {
        delay(800)
        return "oauth_access_${platform.lowercase()}_refreshed_${UUID.randomUUID().toString().take(6)}"
    }

    fun getPlatformScopes(platform: String): String {
        return platformScopes[platform] ?: "profile,publish_content"
    }
}
