package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "social_accounts")
data class SocialAccountEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val platform: String, // YouTube, TikTok, Facebook, Instagram, Threads, Pinterest, X
    val accountName: String = "",
    val accountHandle: String = "",
    val profilePicUrl: String = "",
    val isConnected: Boolean = true,
    val isActiveTarget: Boolean = true,
    val autoPublish: Boolean = true,
    val followerCount: String = "0",
    val reachCount: String = "0",
    val engagementRate: String = "0%",
    val recentPostsCount: Int = 0,
    val status: String = "Active",
    val lastSyncTime: Long = System.currentTimeMillis(),
    val accessToken: String = "",
    val refreshToken: String = "",
    val tokenExpiry: Long = 0L,
    val oauthScopes: String = "profile,publish_content,scheduling,analytics",
    val hasPublishingPermission: Boolean = true,
    val hasSchedulingPermission: Boolean = true,
    val hasAnalyticsPermission: Boolean = true
)

