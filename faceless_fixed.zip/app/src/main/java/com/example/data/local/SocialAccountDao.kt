package com.example.data.local

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface SocialAccountDao {
    @Query("SELECT * FROM social_accounts")
    fun getAllAccounts(): Flow<List<SocialAccountEntity>>

    @Query("SELECT * FROM social_accounts WHERE platform = :platform")
    fun getAccountsForPlatform(platform: String): Flow<List<SocialAccountEntity>>

    @Query("SELECT * FROM social_accounts WHERE id = :id")
    suspend fun getAccountById(id: Long): SocialAccountEntity?

    @Query("SELECT * FROM social_accounts WHERE platform = :platform AND isActiveTarget = 1 LIMIT 1")
    suspend fun getActiveAccountForPlatform(platform: String): SocialAccountEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateAccount(account: SocialAccountEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAccounts(accounts: List<SocialAccountEntity>)

    @Query("UPDATE social_accounts SET isActiveTarget = CASE WHEN id = :selectedId THEN 1 ELSE 0 END WHERE platform = :platform")
    suspend fun setActiveTargetAccount(platform: String, selectedId: Long)

    @Query("UPDATE social_accounts SET isConnected = :isConnected WHERE id = :id")
    suspend fun updateConnectionStatus(id: Long, isConnected: Boolean)

    @Query("UPDATE social_accounts SET isConnected = :isConnected WHERE platform = :platform")
    suspend fun updateConnectionStatusForPlatform(platform: String, isConnected: Boolean)

    @Query("UPDATE social_accounts SET isConnected = :isConnected, accountHandle = :handle, accessToken = :token, refreshToken = :refreshToken, tokenExpiry = :expiry, lastSyncTime = :syncTime WHERE id = :id")
    suspend fun updateOAuthTokensById(id: Long, isConnected: Boolean, handle: String, token: String, refreshToken: String, expiry: Long, syncTime: Long)

    @Query("UPDATE social_accounts SET isConnected = :isConnected, accountHandle = :handle, accessToken = :token, refreshToken = :refreshToken, tokenExpiry = :expiry, lastSyncTime = :syncTime WHERE platform = :platform")
    suspend fun updateOAuthTokens(platform: String, isConnected: Boolean, handle: String, token: String, refreshToken: String, expiry: Long, syncTime: Long)

    @Delete
    suspend fun deleteAccount(account: SocialAccountEntity)

    @Query("DELETE FROM social_accounts WHERE id = :id")
    suspend fun deleteAccountById(id: Long)
}
