# Intergalactic Studio — Android App

## Overview
**Intergalactic Studio** is an Android application (Kotlin / Jetpack Compose) exported from Google AI Studio. It is an AI-powered content creation platform for automated viral faceless video generation, script labs, and multi-platform social publishing.

- **App ID:** `com.aistudio.intergalacticstudio.app`
- **Min SDK:** 24 (Android 7.0)
- **Target SDK:** 36
- **Architecture:** MVVM + Repository pattern, single Activity, Jetpack Compose UI
- **Local storage:** Room database (projects, trends, social accounts)
- **AI:** Gemini 2.0 Flash via Retrofit (`generativelanguage.googleapis.com`)
- **Navigation:** Navigation Compose, single NavHost in `MainActivity`

## Running Locally
This project requires **Android Studio** (Hedgehog or newer) to build and run:

1. Open Android Studio → **Open** → select this directory
2. Create a `.env` file and set `GEMINI_API_KEY=<your-key>` (see `.env.example`)
3. Remove the `signingConfig` line from `app/build.gradle.kts` debug block (noted in README)
4. Run on an emulator or physical device (API 24+)

## Key Files
| Path | Purpose |
|------|---------|
| `app/src/main/java/com/example/MainActivity.kt` | Single activity, NavHost wiring |
| `app/src/main/java/com/example/ui/viewmodels/FacelessViewModel.kt` | Central ViewModel |
| `app/src/main/java/com/example/data/repository/FacelessRepository.kt` | Data layer orchestrator |
| `app/src/main/java/com/example/data/remote/GeminiApiService.kt` | Gemini API client |
| `app/src/main/java/com/example/ui/theme/Theme.kt` | Dark theme + shared `customTextFieldColors()` |
| `gradle/libs.versions.toml` | All dependency versions |

## Screens (Navigation Routes)
| Route | Screen |
|-------|--------|
| `home` | Galactic Command Center dashboard |
| `create` | 7-step content creation workflow + AI assistant |
| `video_library` | Video asset library (grid/list, search, filter) |
| `trending` | Viral trend signal discovery |
| `social_command` | Social accounts dashboard + inbox + bulk publish |
| `calendar` | Content scheduling calendar |
| `projects` | Workspace/folder/campaign project manager |
| `analytics` | Performance analytics & telemetry |
| `media_studio` | Media processing & AI recreation studio |
| `settings` | API keys, social accounts, preferences |

## Environment Variables
- `GEMINI_API_KEY` — Gemini AI API key (required for live AI features; offline fallback exists)

## User Preferences
- Keep the existing Kotlin/Jetpack Compose stack — no migrations
- Maintain dark galactic theme (deep-space dark palette defined in `Color.kt`)
