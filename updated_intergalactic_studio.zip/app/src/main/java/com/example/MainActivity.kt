package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.ui.navigation.BottomNavBar
import com.example.ui.navigation.Screen
import com.example.ui.screens.analytics.AnalyticsScreen
import com.example.ui.screens.calendar.CalendarScreen
import com.example.ui.screens.create.CreateScreen
import com.example.ui.screens.home.HomeScreen
import com.example.ui.screens.library.VideoLibraryScreen
import com.example.ui.screens.projects.ProjectsScreen
import com.example.ui.screens.media.MediaStudioScreen
import com.example.ui.screens.settings.SettingsScreen
import com.example.ui.screens.social.SocialCommandScreen
import com.example.ui.screens.trending.TrendingScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodels.FacelessViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: FacelessViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                IntergalacticStudioApp(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun IntergalacticStudioApp(viewModel: FacelessViewModel) {
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    var pendingTopic by remember { mutableStateOf("") }
    var pendingNiche by remember { mutableStateOf("") }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        bottomBar = {
            BottomNavBar(
                currentRoute = currentRoute,
                onNavigate = { screen ->
                    navController.navigate(screen.route) {
                        popUpTo(navController.graph.startDestinationId) {
                            saveState = true
                        }
                        launchSingleTop = true
                        restoreState = true
                    }
                }
            )
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Home.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(Screen.Home.route) {
                HomeScreen(
                    viewModel = viewModel,
                    onNavigateToScreen = { screen ->
                        navController.navigate(screen.route) {
                            popUpTo(navController.graph.startDestinationId) {
                                saveState = true
                            }
                            launchSingleTop = true
                            restoreState = true
                        }
                    }
                )
            }

            composable(Screen.VideoLibrary.route) {
                VideoLibraryScreen(
                    viewModel = viewModel,
                    onNavigateToCreate = {
                        navController.navigate(Screen.Create.route) {
                            launchSingleTop = true
                        }
                    }
                )
            }

            composable(Screen.SocialCommand.route) {
                SocialCommandScreen(viewModel = viewModel)
            }

            composable(Screen.Create.route) {
                CreateScreen(
                    viewModel = viewModel,
                    initialTopic = pendingTopic,
                    initialNiche = pendingNiche,
                    onProjectCreated = {
                        pendingTopic = ""
                        pendingNiche = ""
                        navController.navigate(Screen.VideoLibrary.route) {
                            popUpTo(navController.graph.startDestinationId)
                        }
                    }
                )
            }

            composable(Screen.Calendar.route) {
                CalendarScreen(viewModel = viewModel)
            }

            composable(Screen.Projects.route) {
                ProjectsScreen(viewModel = viewModel)
            }

            composable(Screen.Trending.route) {
                TrendingScreen(
                    viewModel = viewModel,
                    onNavigateToCreateWithTopic = { topic, niche ->
                        pendingTopic = topic
                        pendingNiche = niche
                        navController.navigate(Screen.Create.route) {
                            launchSingleTop = true
                        }
                    }
                )
            }

            composable(Screen.Analytics.route) {
                AnalyticsScreen(viewModel = viewModel)
            }

            composable(Screen.Settings.route) {
                SettingsScreen(viewModel = viewModel)
            }

            composable(Screen.MediaStudio.route) {
                MediaStudioScreen(
                    onRecreateDone = {
                        navController.navigate(Screen.VideoLibrary.route) {
                            launchSingleTop = true
                        }
                    }
                )
            }
        }
    }
}
