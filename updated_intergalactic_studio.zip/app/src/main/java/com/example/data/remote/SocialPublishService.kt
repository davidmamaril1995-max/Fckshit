package com.example.data.remote

import kotlinx.coroutines.delay

enum class SocialPlatform(val displayName: String, val iconResName: String) {
    YOUTUBE("YouTube Shorts", "ic_youtube"),
    TIKTOK("TikTok", "ic_tiktok"),
    THREADS("Threads", "ic_threads"),
    PINTEREST("Pinterest Pins", "ic_pinterest"),
    FACEBOOK("Facebook Reels", "ic_facebook"),
    INSTAGRAM("Instagram Reels", "ic_instagram"),
    X("X / Twitter", "ic_x")
}

data class PublishResult(
    val platform: String,
    val isSuccess: Boolean,
    val postUrl: String,
    val message: String
)

object SocialPublishService {
    suspend fun publishContent(
        platforms: List<String>,
        title: String,
        scriptBody: String,
        thumbnailUri: String
    ): List<PublishResult> {
        delay(1500) // Simulate network latency and social API endpoint handshakes
        return platforms.map { platform ->
            val randomId = (100000..999999).random()
            val url = when (platform.lowercase().trim()) {
                "youtube", "youtube shorts" -> "https://youtube.com/shorts/v_$randomId"
                "tiktok" -> "https://tiktok.com/@intergalactic_ai/video/$randomId"
                "threads" -> "https://threads.net/@intergalactic_ai/post/$randomId"
                "pinterest", "pinterest pins" -> "https://pinterest.com/pin/$randomId"
                "facebook", "facebook reels" -> "https://facebook.com/reels/$randomId"
                "instagram", "instagram reels" -> "https://instagram.com/p/$randomId"
                "x", "x / twitter", "twitter" -> "https://x.com/IntergalacticAI/status/$randomId"
                else -> "https://${platform.lowercase()}.com/post/$randomId"
            }
            PublishResult(
                platform = platform,
                isSuccess = true,
                postUrl = url,
                message = "Successfully published to $platform"
            )
        }
    }
}
