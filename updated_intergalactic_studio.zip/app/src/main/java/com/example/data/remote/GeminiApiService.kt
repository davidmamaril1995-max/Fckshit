package com.example.data.remote

import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.Query
import java.util.concurrent.TimeUnit

data class GeminiPart(val text: String? = null)

data class GeminiContent(val parts: List<GeminiPart>)

data class GeminiRequest(
    val contents: List<GeminiContent>,
    val systemInstruction: GeminiContent? = null
)

data class GeminiCandidate(val content: GeminiContent)

data class GeminiResponse(val candidates: List<GeminiCandidate>? = null)

interface GeminiApi {
    @POST("v1beta/models/gemini-2.0-flash:generateContent")
    suspend fun generateContent(
        @Query("key") apiKey: String,
        @Body request: GeminiRequest
    ): GeminiResponse
}

object GeminiNetworkClient {
    private const val BASE_URL = "https://generativelanguage.googleapis.com/"

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    val api: GeminiApi by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(MoshiConverterFactory.create())
            .build()
            .create(GeminiApi::class.java)
    }

    suspend fun generateText(prompt: String, systemInstruction: String? = null): String = withContext(Dispatchers.IO) {
        val apiKey = try {
            BuildConfig.GEMINI_API_KEY
        } catch (e: Exception) {
            ""
        }
        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            return@withContext generateOfflineFallback(prompt)
        }

        try {
            val req = GeminiRequest(
                contents = listOf(GeminiContent(parts = listOf(GeminiPart(text = prompt)))),
                systemInstruction = systemInstruction?.let { GeminiContent(parts = listOf(GeminiPart(text = it))) }
            )
            val resp = api.generateContent(apiKey, req)
            resp.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                ?: generateOfflineFallback(prompt)
        } catch (e: Exception) {
            generateOfflineFallback(prompt)
        }
    }

    private fun generateOfflineFallback(prompt: String): String {
        return when {
            prompt.contains("script", ignoreCase = true) || prompt.contains("hook", ignoreCase = true) -> {
                """
                [HOOK 1 - Viral Curiosity]: "Did you know 99% of people get this wrong about AI content in 2026?"
                [HOOK 2 - High Urgency]: "Stop scrolling if you want to launch a 6-figure faceless channel today!"
                [HOOK 3 - Story Starter]: "3 months ago, a faceless creator posted 1 video that changed everything..."

                [BODY NARRATION]:
                Welcome back to Faceless Studio AI. Today we are uncovering the hidden blueprint for high-retention vertical videos. First, keep your visual pacing under 2.5 seconds per scene transition. Second, leverage dynamic captions placed dead-center in the safe frame. Third, pair high-contrast typography with ambient sound effects.

                [CALL TO ACTION]:
                "Comment 'FACeless' below to get our free automated script templates, and don't forget to tap follow for daily trends!"
                """.trimIndent()
            }
            prompt.contains("trend", ignoreCase = true) -> {
                "AI Quantum Computing Advances, 10 Secret Productivity Hacks for 2026, Unexplained Cosmic Mysteries, Dark History Untold"
            }
            else -> {
                "Generated optimized content for: $prompt"
            }
        }
    }
}
