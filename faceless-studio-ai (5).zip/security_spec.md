# Security Specification for Firestore Rules

## 1. Data Invariants
- A user document (`/users/{userId}`) can only be created or written to if `request.auth.uid == userId`.
- Sub-collections (`/users/{userId}/projects/{projectId}`, `/users/{userId}/social_accounts/{accountId}`, `/users/{userId}/scheduled_posts/{postId}`) inherit parent ownership and are strictly accessible only by the owner `userId`.
- Document path variables (`userId`, `projectId`, `accountId`, `postId`) must be validated string IDs matching `^[a-zA-Z0-9_\-]+$`.
- Timestamps must be validated string or server time formats.

## 2. The Dirty Dozen Payloads
1. Attempting to write a project under `/users/otherUser/projects/p1` as `authenticatedUser`.
2. Spoofing `user_id` inside document body when writing to own subcollection.
3. Injecting a 1MB string as a `projectId`.
4. Attempting an unauthenticated list query on `/users/{userId}/projects`.
5. Modifying someone else's connected social account credentials.
6. Shadow updates adding unapproved fields to user profile.
7. Injecting non-string elements into hashtags list.
8. Deleting a user profile as a different user.
9. Attempting to override system created_at timestamps during update.
10. Attempting anonymous writes without verification.
11. Injecting arbitrary HTML or script code into project titles.
12. Attempting a blanket query read without matching `userId`.

## 3. Rule Enforcement Strategy
- Strict rules_version = '2';
- Default deny all match /{document=**} { allow read, write: if false; }
- Owner isolation match /users/{userId} with request.auth.uid == userId
- Sub-collection owner propagation
