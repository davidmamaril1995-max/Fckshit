import React, { useState, useEffect, useRef } from 'react';
import {
  Wand2,
  Sparkles,
  Play,
  Pause,
  Download,
  Share2,
  Image as ImageIcon,
  Mic,
  Subtitles,
  Layers,
  CheckCircle2,
  ChevronRight,
  ArrowLeft,
  Video,
  RefreshCw,
  Clock,
  Calendar,
  AlertCircle,
} from 'lucide-react';
import { Project, AspectRatioOption, SocialPlatform, TrendItem, ConnectedAccount } from '../types.js';
import { api } from '../services/api.js';
import { CanvasVideoRenderer } from '../utils/videoRenderer.js';
import { speakScript } from '../utils/audioSynth.ts';

interface AIPipelineStudioProps {
  initialTrend?: TrendItem | null;
  initialProject?: Project | null;
  connectedAccounts: ConnectedAccount[];
  onProjectSaved: (project: Project) => void;
}

export const AIPipelineStudio: React.FC<AIPipelineStudioProps> = ({
  initialTrend,
  initialProject,
  connectedAccounts,
  onProjectSaved,
}) => {
  const [currentStep, setCurrentStep] = useState<number>(1);
  const [loading, setLoading] = useState<boolean>(false);
  const [loadingText, setLoadingText] = useState<string>('');

  // Step 1 State
  const [topic, setTopic] = useState<string>(initialTrend?.keyword || initialProject?.topic || '');
  const [niche, setNiche] = useState<string>(initialTrend?.category || initialProject?.niche || 'Technology & AI');
  const [aspectRatio, setAspectRatio] = useState<AspectRatioOption>(initialProject?.aspect_ratio || '9:16');
  const [targetDuration, setTargetDuration] = useState<number>(30);
  const [targetPlatform, setTargetPlatform] = useState<SocialPlatform>('youtube_shorts');

  // Generated Pipeline State
  const [script, setScript] = useState<string>(initialProject?.script || '');
  const [title, setTitle] = useState<string>(initialProject?.title || '');
  const [description, setDescription] = useState<string>(initialProject?.description || '');
  const [hashtags, setHashtags] = useState<string[]>(initialProject?.hashtags || []);
  const [scenes, setScenes] = useState<any[]>(initialProject?.scenes || []);
  const [voiceName, setVoiceName] = useState<string>(initialProject?.voice_name || 'Kore');

  // Video Preview Player state
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const rendererRef = useRef<CanvasVideoRenderer | null>(null);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [totalDuration, setTotalDuration] = useState<number>(18);
  const [isExporting, setIsExporting] = useState<boolean>(false);

  // Publish Modal State
  const [showPublishModal, setShowPublishModal] = useState<boolean>(false);
  const [selectedAccountId, setSelectedAccountId] = useState<string>('');
  const [scheduledTime, setScheduledTime] = useState<string>('');
  const [publishStatus, setPublishStatus] = useState<string>('');

  // Additional AI Model Configuration State
  const [scriptEngine, setScriptEngine] = useState<string>('gemini_3_6_flash');
  const [imageEngine, setImageEngine] = useState<string>('gemini_imagen_3');
  const [voiceEngine, setVoiceEngine] = useState<string>('elevenlabs');
  const [voiceStability, setVoiceStability] = useState<number>(0.75);
  const [voiceClarity, setVoiceClarity] = useState<number>(0.85);

  // Auto-Save Indicator State
  const [saveStatus, setSaveStatus] = useState<'saved' | 'saving' | 'error' | 'idle'>('saved');
  const [lastSavedTime, setLastSavedTime] = useState<string | null>(
    new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })
  );
  const isFirstRender = useRef(true);

  const saveCurrentProject = async () => {
    if (!topic && !script && !title) return;
    setSaveStatus('saving');
    try {
      const subtitlesData = scenes.map((s, idx) => ({
        id: `sub_${idx}`,
        start: idx * 4.5,
        end: (idx + 1) * 4.5,
        text: s.narration || '',
        highlightWord: (s.narration || '').split(' ')[0],
      }));

      const projectBlueprint: Project = {
        id: initialProject?.id || `proj_${Date.now()}`,
        name: title || topic || 'Untitled Video',
        topic,
        niche,
        aspect_ratio: aspectRatio,
        script,
        title: title || topic,
        description,
        hashtags,
        captions: script.slice(0, 100),
        thumbnails: scenes.map((s) => s.imageUrl).filter(Boolean),
        scenes,
        voice_name: voiceName,
        subtitles: subtitlesData,
        status: currentStep === 5 ? 'generated' : 'draft',
        created_at: initialProject?.created_at || new Date().toISOString(),
        updated_at: new Date().toISOString(),
      };

      const saved = await api.saveProject(projectBlueprint);
      onProjectSaved(saved);
      setSaveStatus('saved');
      setLastSavedTime(new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }));
    } catch (err) {
      console.error('Auto-save error:', err);
      setSaveStatus('error');
    }
  };

  useEffect(() => {
    if (isFirstRender.current) {
      isFirstRender.current = false;
      return;
    }

    setSaveStatus('saving');
    const timer = setTimeout(() => {
      saveCurrentProject();
    }, 1200);

    return () => clearTimeout(timer);
  }, [topic, niche, aspectRatio, script, title, description, hashtags, scenes, voiceName, currentStep]);

  useEffect(() => {
    if (initialTrend) {
      setTopic(initialTrend.keyword);
      setNiche(initialTrend.category);
    }
  }, [initialTrend]);

  // Handle Step 1 -> Step 2 AI Script Generation
  const handleGenerateScript = async () => {
    if (!topic) return;
    setLoading(true);
    setLoadingText(`Analyzing trend hooks & writing viral script with ${scriptEngine.toUpperCase().replace(/_/g, ' ')}...`);

    try {
      const result = await api.generateScript({
        topic,
        niche,
        targetDurationSeconds: targetDuration,
        aspectRatio,
        targetPlatform,
        scriptEngine,
      });

      setScript(result.script);
      setTitle(result.title);
      setDescription(result.description);
      setHashtags(result.hashtags);
      setScenes(
        result.scenes.map((s) => ({
          id: `sc_${s.sceneNumber}_${Date.now()}`,
          sceneNumber: s.sceneNumber,
          narration: s.narration,
          visualPrompt: s.visualPrompt,
          duration: s.suggestedDuration || 4,
          imageUrl: '',
        }))
      );

      setCurrentStep(2);
    } catch (err) {
      console.error('Failed to generate script:', err);
    } finally {
      setLoading(false);
    }
  };

  // Handle Step 3 Visual Scene Image Generation
  const handleGenerateAllImages = async () => {
    setLoading(true);
    setLoadingText(`Generating high-resolution AI visuals with ${imageEngine.toUpperCase().replace(/_/g, ' ')}...`);

    try {
      const updatedScenes = [...scenes];
      for (let i = 0; i < updatedScenes.length; i++) {
        setLoadingText(`Generating Scene ${i + 1} of ${updatedScenes.length} via ${imageEngine.toUpperCase()}...`);
        const imgUrl = await api.generateSceneImage(updatedScenes[i].visualPrompt, aspectRatio, imageEngine);
        updatedScenes[i].imageUrl = imgUrl;
      }
      setScenes(updatedScenes);
      setCurrentStep(4);
    } catch (err) {
      console.error('Error generating images:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleRegenerateSceneImage = async (index: number) => {
    const updated = [...scenes];
    setLoadingText(`Regenerating Scene ${index + 1} via ${imageEngine.toUpperCase()}...`);
    try {
      const newUrl = await api.generateSceneImage(updated[index].visualPrompt, aspectRatio, imageEngine);
      updated[index].imageUrl = newUrl;
      setScenes(updated);
    } catch (err) {
      console.error(err);
    }
  };

  // Initialize Canvas Video Renderer in Step 5
  useEffect(() => {
    if (currentStep === 5 && canvasRef.current) {
      const projectBlueprint: Project = {
        id: initialProject?.id || `proj_${Date.now()}`,
        name: title || topic,
        topic,
        niche,
        aspect_ratio: aspectRatio,
        script,
        title,
        description,
        hashtags,
        captions: script.slice(0, 100),
        thumbnails: scenes.map((s) => s.imageUrl).filter(Boolean),
        scenes,
        voice_name: voiceName,
        subtitles: scenes.map((s, idx) => ({
          id: `sub_${idx}`,
          start: idx * 4.5,
          end: (idx + 1) * 4.5,
          text: s.narration,
          highlightWord: s.narration.split(' ')[0],
        })),
        status: 'generated',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      };

      if (!rendererRef.current) {
        rendererRef.current = new CanvasVideoRenderer(canvasRef.current, projectBlueprint);
      } else {
        rendererRef.current.updateProject(projectBlueprint);
      }

      setTotalDuration(rendererRef.current.getTotalDuration());
      rendererRef.current.renderFrame();

      onProjectSaved(projectBlueprint);
    }
  }, [currentStep, scenes, aspectRatio, title, script, voiceName]);

  const togglePlayPause = () => {
    if (!rendererRef.current) return;
    if (isPlaying) {
      rendererRef.current.pause();
      setIsPlaying(false);
    } else {
      setIsPlaying(true);
      speakScript(script, voiceName);
      rendererRef.current.play(
        (timeSec) => setCurrentTime(timeSec),
        () => setIsPlaying(false)
      );
    }
  };

  const handleExportVideoFile = async () => {
    if (!rendererRef.current) return;
    setIsExporting(true);
    try {
      const blob = await rendererRef.current.exportVideo();
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${title.replace(/[^a-zA-Z0-9]/g, '_')}.webm`;
      a.click();
    } catch (err) {
      console.error('Video export error:', err);
    } finally {
      setIsExporting(false);
    }
  };

  const handlePublishProject = async () => {
    setPublishStatus('Publishing video to selected social platform...');
    try {
      const res = await api.publishProject({
        projectId: initialProject?.id || `proj_${Date.now()}`,
        accountId: selectedAccountId,
        platform: targetPlatform,
        scheduledTime: scheduledTime || undefined,
      });

      setPublishStatus(res.message);
      setTimeout(() => {
        setShowPublishModal(false);
        setPublishStatus('');
      }, 2000);
    } catch (err) {
      setPublishStatus('Failed to publish video.');
    }
  };

  return (
    <div className="space-y-6 pb-12 max-w-5xl mx-auto">
      {/* Studio Header Bar & Auto-Save Indicator Icon */}
      <div className="bg-[#0D1120] border border-indigo-900/40 rounded-2xl p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-md">
        <div className="flex items-center space-x-3">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-cyan-500 to-indigo-600 flex items-center justify-center text-white shadow-md shrink-0">
            <Wand2 className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h1 className="text-base font-bold text-white tracking-tight">
                {title || topic || 'Untitled Video Project'}
              </h1>
              <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded-md bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 font-bold">
                Step {currentStep} / 5
              </span>
            </div>
            <p className="text-xs text-indigo-300/70">Faceless AI Video Pipeline Studio</p>
          </div>
        </div>

        {/* Auto-Save Status Badge / Button */}
        <button
          type="button"
          onClick={() => saveCurrentProject()}
          className={`flex items-center space-x-2 px-3 py-1.5 rounded-xl border text-xs font-semibold transition-all cursor-pointer ${
            saveStatus === 'saving'
              ? 'bg-amber-500/15 border-amber-500/30 text-amber-300 shadow-sm'
              : saveStatus === 'error'
              ? 'bg-rose-500/15 border-rose-500/30 text-rose-300 hover:bg-rose-500/25'
              : 'bg-emerald-500/15 border-emerald-500/30 text-emerald-300 hover:bg-emerald-500/25'
          }`}
          title="Auto-save status. Click to manually save now."
        >
          {saveStatus === 'saving' ? (
            <>
              <RefreshCw className="w-3.5 h-3.5 animate-spin text-amber-400" />
              <span className="font-mono">Saving...</span>
            </>
          ) : saveStatus === 'error' ? (
            <>
              <AlertCircle className="w-3.5 h-3.5 text-rose-400" />
              <span>Error Saving (Retry)</span>
            </>
          ) : (
            <>
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
              <span>Saved</span>
              {lastSavedTime && <span className="text-[10px] text-emerald-400/80 font-mono">({lastSavedTime})</span>}
            </>
          )}
        </button>
      </div>

      {/* Step Indicator Header */}
      <div className="bg-[#0D1117] border border-gray-800 rounded-2xl p-4 flex items-center justify-between overflow-x-auto">
        {[
          { num: 1, label: 'Topic & Config', icon: Wand2 },
          { num: 2, label: 'AI Script', icon: Sparkles },
          { num: 3, label: 'Visual Scenes', icon: ImageIcon },
          { num: 4, label: 'Voice & Subs', icon: Mic },
          { num: 5, label: 'Assembly & Export', icon: Video },
        ].map((step) => {
          const Icon = step.icon;
          const isDone = currentStep > step.num;
          const isCurrent = currentStep === step.num;
          return (
            <button
              key={step.num}
              onClick={() => {
                if (step.num < currentStep) setCurrentStep(step.num);
              }}
              className={`flex items-center space-x-2 px-3 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap ${
                isCurrent
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                  : isDone
                  ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                  : 'text-gray-500 hover:text-gray-300'
              }`}
            >
              <div className="w-5 h-5 rounded-full flex items-center justify-center text-[10px] bg-black/20 font-extrabold">
                {isDone ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> : step.num}
              </div>
              <span>{step.label}</span>
            </button>
          );
        })}
      </div>

      {/* Loading Overlay State */}
      {loading && (
        <div className="bg-[#0D1117] border border-indigo-500/30 rounded-3xl p-12 text-center space-y-4">
          <RefreshCw className="w-10 h-10 text-indigo-400 animate-spin mx-auto" />
          <h3 className="text-lg font-bold text-white">AI Studio Working</h3>
          <p className="text-sm text-gray-400 max-w-md mx-auto">{loadingText}</p>
        </div>
      )}

      {/* STEP 1: TOPIC & CONFIG */}
      {!loading && currentStep === 1 && (
        <div className="bg-[#0D1117] border border-gray-800 rounded-3xl p-6 md:p-8 space-y-6">
          <div className="space-y-1">
            <h2 className="text-xl font-bold text-white">Configure Faceless Video Blueprint</h2>
            <p className="text-xs text-gray-400">Select target format, niche topic, and aspect ratio.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            <div className="space-y-2">
              <label className="text-xs font-semibold text-gray-300">Topic or Concept Keyword</label>
              <input
                type="text"
                placeholder="e.g. 5 AI Tools Replacing 9-to-5 Jobs in 2026"
                value={topic}
                onChange={(e) => setTopic(e.target.value)}
                className="w-full bg-gray-900 border border-gray-800 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div className="space-y-2">
              <label className="text-xs font-semibold text-gray-300">Niche Category</label>
              <select
                value={niche}
                onChange={(e) => setNiche(e.target.value)}
                className="w-full bg-gray-900 border border-gray-800 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-indigo-500"
              >
                <option value="Technology & AI">Technology & AI</option>
                <option value="Finance & Money">Finance & Money</option>
                <option value="Cybersecurity & Future">Cybersecurity & Future</option>
                <option value="Mindset & Self Improvement">Mindset & Self Improvement</option>
                <option value="Philosophy & Mindset">Philosophy & Mindset</option>
                <option value="Business & Entrepreneurship">Business & Entrepreneurship</option>
              </select>
            </div>

            <div className="space-y-2">
              <label className="text-xs font-semibold text-gray-300">Aspect Ratio & Format</label>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { ratio: '9:16', name: 'Vertical (Shorts/Reels)' },
                  { ratio: '16:9', name: 'Landscape (YouTube)' },
                  { ratio: '1:1', name: 'Square (Post)' },
                ].map((item) => (
                  <button
                    key={item.ratio}
                    type="button"
                    onClick={() => setAspectRatio(item.ratio as AspectRatioOption)}
                    className={`p-3 rounded-xl border text-center transition-all cursor-pointer ${
                      aspectRatio === item.ratio
                        ? 'bg-indigo-600/20 border-indigo-500 text-indigo-300'
                        : 'bg-gray-900 border-gray-800 text-gray-400 hover:text-white'
                    }`}
                  >
                    <div className="text-xs font-bold">{item.ratio}</div>
                    <div className="text-[10px] text-gray-500 mt-1">{item.name}</div>
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-xs font-semibold text-gray-300">Script Generation AI Engine</label>
              <select
                value={scriptEngine}
                onChange={(e) => setScriptEngine(e.target.value)}
                className="w-full bg-[#11162B] border border-cyan-500/30 rounded-xl px-4 py-2.5 text-sm text-cyan-200 focus:outline-none focus:border-cyan-400 font-semibold"
              >
                <option value="gemini_3_6_flash">Google Gemini 3.6 Flash (Fastest)</option>
                <option value="gpt_4o">OpenAI GPT-4o Omni</option>
                <option value="claude_3_5_sonnet">Anthropic Claude 3.5 Sonnet</option>
                <option value="deepseek_v3">DeepSeek V3 Viral Creative</option>
              </select>
            </div>

            <div className="space-y-2">
              <label className="text-xs font-semibold text-gray-300">Target Social Platform</label>
              <select
                value={targetPlatform}
                onChange={(e) => setTargetPlatform(e.target.value as SocialPlatform)}
                className="w-full bg-gray-900 border border-gray-800 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-indigo-500 capitalize"
              >
                <option value="youtube_shorts">YouTube Shorts</option>
                <option value="tiktok">TikTok</option>
                <option value="facebook_reels">Facebook Reels</option>
                <option value="instagram_reels">Instagram Reels</option>
                <option value="threads">Threads</option>
                <option value="pinterest">Pinterest</option>
              </select>
            </div>
          </div>

          <button
            onClick={handleGenerateScript}
            disabled={!topic}
            className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white py-3.5 rounded-2xl font-bold shadow-lg shadow-indigo-600/25 transition-all flex items-center justify-center space-x-2 cursor-pointer disabled:opacity-50"
          >
            <Wand2 className="w-4 h-4" />
            <span>Generate AI Script & Viral Blueprint</span>
          </button>
        </div>
      )}

      {/* STEP 2: AI SCRIPT EDITOR */}
      {!loading && currentStep === 2 && (
        <div className="bg-[#0D1117] border border-gray-800 rounded-3xl p-6 md:p-8 space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-xl font-bold text-white">Review & Edit AI Script</h2>
              <p className="text-xs text-gray-400">Gemini generated viral hook, body narrative, and SEO metadata.</p>
            </div>
            <button
              onClick={() => setCurrentStep(1)}
              className="text-xs text-gray-400 hover:text-white flex items-center space-x-1"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Back</span>
            </button>
          </div>

          <div className="space-y-4">
            <div className="space-y-2">
              <label className="text-xs font-semibold text-gray-300">Viral SEO Title</label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="w-full bg-gray-900 border border-gray-800 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div className="space-y-2">
              <label className="text-xs font-semibold text-gray-300">Spoken Script Narration</label>
              <textarea
                rows={4}
                value={script}
                onChange={(e) => setScript(e.target.value)}
                className="w-full bg-gray-900 border border-gray-800 rounded-xl p-4 text-sm text-white focus:outline-none focus:border-indigo-500"
              />
            </div>

            {/* Scene breakdown preview */}
            <div className="space-y-2">
              <label className="text-xs font-semibold text-gray-300">Scene Breakdown ({scenes.length} Scenes)</label>
              <div className="space-y-2">
                {scenes.map((sc, index) => (
                  <div key={sc.id || index} className="bg-gray-900 border border-gray-800 rounded-xl p-3.5 space-y-2">
                    <div className="flex items-center justify-between text-xs font-bold text-indigo-400">
                      <span>Scene {index + 1} ({sc.duration}s)</span>
                    </div>
                    <p className="text-xs text-white">{sc.narration}</p>
                    <p className="text-[11px] text-gray-400 italic">Prompt: {sc.visualPrompt}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <button
            onClick={() => setCurrentStep(3)}
            className="w-full bg-indigo-600 hover:bg-indigo-500 text-white py-3.5 rounded-2xl font-bold shadow-lg shadow-indigo-600/25 transition-all flex items-center justify-center space-x-2 cursor-pointer"
          >
            <span>Proceed To Visual Scene Generator</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* STEP 3: VISUAL SCENE GENERATOR */}
      {!loading && currentStep === 3 && (
        <div className="bg-[#0D1117] border border-indigo-900/40 rounded-3xl p-6 md:p-8 space-y-6">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-indigo-900/40">
            <div>
              <h2 className="text-xl font-bold text-white">Generate AI Visual Scenes</h2>
              <p className="text-xs text-indigo-300/70">Select your AI visual generation engine and generate custom 8k scene art.</p>
            </div>

            <div className="flex items-center space-x-3">
              <label className="text-xs font-semibold text-cyan-300">Image Generator Engine:</label>
              <select
                value={imageEngine}
                onChange={(e) => setImageEngine(e.target.value)}
                className="bg-[#11162B] border border-cyan-500/40 rounded-xl px-3 py-1.5 text-xs text-cyan-200 font-bold focus:outline-none"
              >
                <option value="gemini_imagen_3">Google Imagen 3 (Default)</option>
                <option value="midjourney_v6">Midjourney v6 Photorealistic</option>
                <option value="stable_diffusion_3_5">Stable Diffusion 3.5 FLUX</option>
                <option value="dalle_3">OpenAI DALL-E 3</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {scenes.map((sc, index) => (
              <div key={sc.id || index} className="bg-[#0D1120] border border-indigo-900/50 rounded-2xl p-4 space-y-3">
                <div className="aspect-video bg-black rounded-xl overflow-hidden relative border border-indigo-900/60 shadow-inner">
                  {sc.imageUrl ? (
                    <img src={sc.imageUrl} alt={`Scene ${index + 1}`} className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full flex flex-col items-center justify-center p-4 text-center text-indigo-300/50 space-y-2">
                      <ImageIcon className="w-8 h-8 text-cyan-400/60" />
                      <span className="text-xs font-mono">Image render pending...</span>
                    </div>
                  )}
                </div>

                <div className="space-y-1">
                  <span className="text-xs font-bold text-cyan-400">Scene {index + 1}</span>
                  <p className="text-xs text-white line-clamp-2">{sc.narration}</p>
                </div>

                <button
                  onClick={() => handleRegenerateSceneImage(index)}
                  className="w-full bg-[#11162B] hover:bg-indigo-900/50 text-xs text-cyan-300 py-2 rounded-xl font-semibold transition-all border border-indigo-900/50 flex items-center justify-center space-x-1.5 cursor-pointer"
                >
                  <RefreshCw className="w-3 h-3 text-cyan-400" />
                  <span>Regenerate with {imageEngine.toUpperCase().split('_')[0]}</span>
                </button>
              </div>
            ))}
          </div>

          <button
            onClick={handleGenerateAllImages}
            className="w-full bg-gradient-to-r from-cyan-500 via-indigo-600 to-fuchsia-600 hover:from-cyan-400 hover:to-fuchsia-500 text-white py-3.5 rounded-2xl font-bold shadow-lg shadow-cyan-500/25 transition-all flex items-center justify-center space-x-2 cursor-pointer"
          >
            <Sparkles className="w-4 h-4" />
            <span>Generate All AI Images & Proceed To Voice Engine</span>
          </button>
        </div>
      )}

      {/* STEP 4: VOICE SYNTHESIS & ELEVENLABS ENGINE */}
      {!loading && currentStep === 4 && (
        <div className="bg-[#0D1117] border border-indigo-900/40 rounded-3xl p-6 md:p-8 space-y-6">
          <div className="flex items-center justify-between pb-4 border-b border-indigo-900/40">
            <div>
              <h2 className="text-xl font-bold text-white">ElevenLabs & AI Voice Synthesis</h2>
              <p className="text-xs text-indigo-300/70">Ultra-realistic deep Voiceover with ElevenLabs, Gemini TTS & OpenAI Voice.</p>
            </div>
            <button
              onClick={() => setCurrentStep(3)}
              className="text-xs text-indigo-300 hover:text-white flex items-center space-x-1 cursor-pointer"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Back</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4 bg-[#0D1120] p-5 rounded-2xl border border-indigo-900/50">
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-cyan-300">Voice Synthesis Provider</label>
                <select
                  value={voiceEngine}
                  onChange={(e) => setVoiceEngine(e.target.value)}
                  className="w-full bg-[#11162B] border border-cyan-500/40 rounded-xl px-4 py-2.5 text-sm text-cyan-200 font-bold focus:outline-none"
                >
                  <option value="elevenlabs">ElevenLabs Multilingual v2 (Premium Ultra-Realism)</option>
                  <option value="gemini_tts">Google Gemini Neural TTS</option>
                  <option value="openai_tts">OpenAI Voice Synthesizer</option>
                </select>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-bold text-indigo-200">Voice Profile / Speaker</label>
                <select
                  value={voiceName}
                  onChange={(e) => setVoiceName(e.target.value)}
                  className="w-full bg-[#11162B] border border-indigo-900/60 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-cyan-400"
                >
                  <option value="Adam (ElevenLabs Deep Gravitas)">Adam (ElevenLabs Deep Gravitas)</option>
                  <option value="Rachel (ElevenLabs Calm & Conversational)">Rachel (ElevenLabs Calm & Conversational)</option>
                  <option value="Josh (ElevenLabs Tech Educator)">Josh (ElevenLabs Tech Educator)</option>
                  <option value="Bella (ElevenLabs Energetic Female)">Bella (ElevenLabs Energetic Female)</option>
                  <option value="Antoni (ElevenLabs Master Narrator)">Antoni (ElevenLabs Master Narrator)</option>
                  <option value="Domi (ElevenLabs Bold Accent)">Domi (ElevenLabs Bold Accent)</option>
                  <option value="Arnold (ElevenLabs High Energy)">Arnold (ElevenLabs High Energy)</option>
                  <option value="Kore (Gemini Energetic Female)">Kore (Gemini Energetic Female)</option>
                  <option value="Fenrir (Gemini Deep Male)">Fenrir (Gemini Deep Male)</option>
                </select>
              </div>

              {voiceEngine === 'elevenlabs' && (
                <div className="space-y-3 pt-2 border-t border-indigo-900/40">
                  <div className="space-y-1">
                    <div className="flex justify-between text-xs font-semibold">
                      <span className="text-indigo-300">Voice Stability:</span>
                      <span className="text-cyan-300">{Math.round(voiceStability * 100)}%</span>
                    </div>
                    <input
                      type="range"
                      min="0"
                      max="1"
                      step="0.05"
                      value={voiceStability}
                      onChange={(e) => setVoiceStability(parseFloat(e.target.value))}
                      className="w-full accent-cyan-400 bg-gray-800 rounded-lg cursor-pointer"
                    />
                  </div>

                  <div className="space-y-1">
                    <div className="flex justify-between text-xs font-semibold">
                      <span className="text-indigo-300">Clarity & Similarity Boost:</span>
                      <span className="text-cyan-300">{Math.round(voiceClarity * 100)}%</span>
                    </div>
                    <input
                      type="range"
                      min="0"
                      max="1"
                      step="0.05"
                      value={voiceClarity}
                      onChange={(e) => setVoiceClarity(parseFloat(e.target.value))}
                      className="w-full accent-cyan-400 bg-gray-800 rounded-lg cursor-pointer"
                    />
                  </div>
                </div>
              )}
            </div>

            <div className="space-y-4 bg-[#0D1120] p-5 rounded-2xl border border-indigo-900/50 flex flex-col justify-between">
              <div className="space-y-2">
                <label className="text-xs font-bold text-cyan-300">Subtitle & Caption Style</label>
                <div className="p-4 bg-black/60 border border-indigo-500/40 rounded-xl text-center shadow-inner">
                  <span className="text-sm font-extrabold text-cyan-300 bg-indigo-950/80 px-3 py-1.5 rounded-xl border border-cyan-400/50 shadow-lg tracking-wide uppercase">
                    ANIMATED HIGHLIGHT CAPTIONS
                  </span>
                </div>
                <p className="text-xs text-indigo-300/70 pt-2">
                  Subtitles automatically highlight word-by-word with high contrast glowing text on black pill backdrops.
                </p>
              </div>

              <div className="p-3 bg-cyan-500/10 border border-cyan-500/20 rounded-xl text-[11px] text-cyan-300">
                ⚡ ElevenLabs & Gemini voice engine is active and ready for assembly.
              </div>
            </div>
          </div>

          <button
            onClick={() => setCurrentStep(5)}
            className="w-full bg-gradient-to-r from-cyan-500 via-indigo-600 to-fuchsia-600 hover:from-cyan-400 hover:to-fuchsia-500 text-white py-3.5 rounded-2xl font-bold shadow-lg shadow-cyan-500/25 transition-all flex items-center justify-center space-x-2 cursor-pointer"
          >
            <span>Compile Video & Open Studio Player</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* STEP 5: VIDEO STUDIO CANVAS ASSEMBLY & EXPORT */}
      {!loading && currentStep === 5 && (
        <div className="bg-[#0D1117] border border-gray-800 rounded-3xl p-6 md:p-8 space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-xl font-bold text-white">Studio Canvas Assembly</h2>
              <p className="text-xs text-gray-400">Real-time canvas video player with audio subtitle sync.</p>
            </div>
            <button
              onClick={() => setCurrentStep(4)}
              className="text-xs text-gray-400 hover:text-white flex items-center space-x-1"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Back</span>
            </button>
          </div>

          <div className="flex flex-col md:flex-row items-center justify-center gap-6">
            {/* Canvas Video Viewport */}
            <div className="relative bg-black rounded-3xl overflow-hidden border border-gray-800 shadow-2xl max-w-sm w-full">
              <canvas ref={canvasRef} className="w-full h-auto block" />

              {/* Overlay Controls */}
              <div className="absolute bottom-4 left-4 right-4 bg-black/60 backdrop-blur-md rounded-2xl p-3 flex items-center justify-between border border-white/10">
                <button
                  onClick={togglePlayPause}
                  className="w-10 h-10 rounded-xl bg-indigo-600 text-white flex items-center justify-center shadow-lg cursor-pointer"
                >
                  {isPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5 ml-0.5" />}
                </button>
                <div className="text-xs font-mono text-gray-300">
                  {currentTime.toFixed(1)}s / {totalDuration.toFixed(1)}s
                </div>
              </div>
            </div>

            {/* Side Action Panel */}
            <div className="space-y-4 w-full max-w-md">
              <div className="bg-gray-900 border border-gray-800 rounded-2xl p-4 space-y-3">
                <h4 className="text-sm font-bold text-white">{title || 'Faceless Video Blueprint'}</h4>
                <p className="text-xs text-gray-300">{script}</p>
                <div className="flex flex-wrap gap-1">
                  {hashtags.map((h, i) => (
                    <span key={i} className="text-[10px] text-indigo-400 bg-indigo-500/10 px-2 py-0.5 rounded-md">
                      {h}
                    </span>
                  ))}
                </div>
              </div>

              <div className="space-y-2">
                <button
                  onClick={handleExportVideoFile}
                  disabled={isExporting}
                  className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white py-3.5 rounded-2xl font-bold shadow-lg shadow-indigo-600/25 transition-all flex items-center justify-center space-x-2 cursor-pointer disabled:opacity-50"
                >
                  <Download className="w-4 h-4" />
                  <span>{isExporting ? 'Rendering Video File...' : 'Download Rendered MP4/WebM'}</span>
                </button>

                <button
                  onClick={() => setShowPublishModal(true)}
                  className="w-full bg-emerald-600 hover:bg-emerald-500 text-white py-3.5 rounded-2xl font-bold shadow-lg shadow-emerald-600/25 transition-all flex items-center justify-center space-x-2 cursor-pointer"
                >
                  <Share2 className="w-4 h-4" />
                  <span>Publish / Schedule To Social Channel</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Publish Modal */}
      {showPublishModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-[#0D1117] border border-gray-800 rounded-3xl p-6 max-w-md w-full space-y-5">
            <h3 className="text-lg font-bold text-white">Publish Video Blueprint</h3>

            <div className="space-y-3">
              <label className="text-xs font-semibold text-gray-300">Select Connected Account</label>
              <select
                value={selectedAccountId}
                onChange={(e) => setSelectedAccountId(e.target.value)}
                className="w-full bg-gray-900 border border-gray-800 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-indigo-500"
              >
                <option value="">Default Account Channel</option>
                {connectedAccounts.map((acc) => (
                  <option key={acc.account_id} value={acc.account_id}>
                    {acc.account_name} ({acc.platform})
                  </option>
                ))}
              </select>

              <label className="text-xs font-semibold text-gray-300">Schedule Time (Optional for auto-publish)</label>
              <input
                type="datetime-local"
                value={scheduledTime}
                onChange={(e) => setScheduledTime(e.target.value)}
                className="w-full bg-gray-900 border border-gray-800 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-indigo-500"
              />

              {publishStatus && <p className="text-xs font-medium text-emerald-400">{publishStatus}</p>}
            </div>

            <div className="flex items-center space-x-3 pt-2">
              <button
                onClick={() => setShowPublishModal(false)}
                className="flex-1 bg-gray-800 hover:bg-gray-700 text-gray-300 py-2.5 rounded-xl text-xs font-semibold"
              >
                Cancel
              </button>
              <button
                onClick={handlePublishProject}
                className="flex-1 bg-indigo-600 hover:bg-indigo-500 text-white py-2.5 rounded-xl text-xs font-semibold"
              >
                Confirm Publish
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
