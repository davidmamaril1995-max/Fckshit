import { Router, Request, Response } from 'express';
import { dbManager } from '../db.js';

export const dbRouter = Router();

// Full Database Export (for backup/sync)
dbRouter.get('/export', (req: Request, res: Response) => {
  res.json({ success: true, data: dbManager.getFullDb() });
});

// Users
dbRouter.get('/users', (req: Request, res: Response) => {
  res.json({ success: true, users: dbManager.getUsers() });
});

dbRouter.post('/users', (req: Request, res: Response) => {
  const user = dbManager.updateUser(req.body);
  res.json({ success: true, user });
});

// Connected Accounts
dbRouter.get('/connected-accounts', (req: Request, res: Response) => {
  res.json({ success: true, accounts: dbManager.getConnectedAccounts() });
});

dbRouter.post('/connected-accounts', (req: Request, res: Response) => {
  const account = dbManager.saveConnectedAccount(req.body);
  res.json({ success: true, account });
});

dbRouter.delete('/connected-accounts/:id', (req: Request, res: Response) => {
  const success = dbManager.deleteConnectedAccount(req.params.id);
  res.json({ success });
});

// AI Provider Settings
dbRouter.get('/ai-providers', (req: Request, res: Response) => {
  res.json({ success: true, providers: dbManager.getAIProviders() });
});

dbRouter.post('/ai-providers', (req: Request, res: Response) => {
  const provider = dbManager.saveAIProvider(req.body);
  res.json({ success: true, provider });
});

// Projects
dbRouter.get('/projects', (req: Request, res: Response) => {
  res.json({ success: true, projects: dbManager.getProjects() });
});

dbRouter.get('/projects/:id', (req: Request, res: Response) => {
  const project = dbManager.getProject(req.params.id);
  if (!project) {
    res.status(404).json({ error: 'Project not found' });
    return;
  }
  res.json({ success: true, project });
});

dbRouter.post('/projects', (req: Request, res: Response) => {
  const project = dbManager.saveProject(req.body);
  res.json({ success: true, project });
});

dbRouter.delete('/projects/:id', (req: Request, res: Response) => {
  const success = dbManager.deleteProject(req.params.id);
  res.json({ success });
});

// Upload History
dbRouter.get('/upload-history', (req: Request, res: Response) => {
  res.json({ success: true, history: dbManager.getUploadHistory() });
});

dbRouter.post('/upload-history', (req: Request, res: Response) => {
  const record = dbManager.addUploadRecord(req.body);
  res.json({ success: true, record });
});

// Scheduled Posts
dbRouter.get('/scheduled-posts', (req: Request, res: Response) => {
  res.json({ success: true, scheduledPosts: dbManager.getScheduledPosts() });
});

dbRouter.post('/scheduled-posts', (req: Request, res: Response) => {
  const scheduledPost = dbManager.saveScheduledPost(req.body);
  res.json({ success: true, scheduledPost });
});

dbRouter.delete('/scheduled-posts/:id', (req: Request, res: Response) => {
  const success = dbManager.deleteScheduledPost(req.params.id);
  res.json({ success });
});

// Preferences
dbRouter.get('/preferences', (req: Request, res: Response) => {
  res.json({ success: true, preferences: dbManager.getPreferences() });
});

dbRouter.post('/preferences', (req: Request, res: Response) => {
  const preferences = dbManager.updatePreferences(req.body);
  res.json({ success: true, preferences });
});
