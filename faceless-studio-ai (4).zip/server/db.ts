import fs from 'fs';
import path from 'path';
import {
  User,
  ConnectedAccount,
  AIProviderConfig,
  TrendItem,
  Project,
  UploadHistory,
  ScheduledPost,
  UserPreferences,
} from '../src/types.js';

interface DatabaseSchema {
  users: User[];
  connectedAccounts: ConnectedAccount[];
  aiProviders: AIProviderConfig[];
  trendCache: TrendItem[];
  projects: Project[];
  uploadHistory: UploadHistory[];
  scheduledPosts: ScheduledPost[];
  preferences: UserPreferences;
}

const DB_DIR = path.join(process.cwd(), 'data');
const DB_FILE = path.join(DB_DIR, 'faceless_studio_db.json');

const defaultPreferences: UserPreferences = {
  user_id: 'usr_default_01',
  theme: 'dark',
  dark_mode: true,
  language: 'en',
  default_ai_provider: 'google_gemini',
  preferred_voice: 'Kore (Energetic Female)',
  preferred_aspect_ratio: '9:16',
  export_settings: {
    resolution: '1080p',
    fps: 30,
    format: 'mp4',
  },
  video_quality: 'high',
  subtitle_preferences: {
    fontFamily: 'Plus Jakarta Sans',
    fontSize: 28,
    fontColor: '#FFFFFF',
    backgroundColor: 'rgba(0,0,0,0.75)',
    position: 'bottom',
    animation: 'pop',
  },
};

const defaultUsers: User[] = [
  {
    user_id: 'usr_default_01',
    email: 'creator@faceless.studio',
    display_name: 'Studio Creator',
    subscription: 'creator_pro',
    preferences: defaultPreferences,
    created_at: new Date('2026-01-15T10:00:00Z').toISOString(),
    updated_at: new Date().toISOString(),
  },
];

const defaultConnectedAccounts: ConnectedAccount[] = [
  {
    account_id: 'acc_yt_01',
    user_id: 'usr_default_01',
    platform: 'youtube_shorts',
    account_name: 'Tech Mindset Shorts',
    channel_id: 'UC_TechMindset99',
    connection_status: 'connected',
    scopes: ['https://www.googleapis.com/auth/youtube.upload', 'channel.readonly'],
    profile_image: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=150&auto=format&fit=crop&q=80',
    followers_count: 48200,
    created_at: new Date('2026-02-01').toISOString(),
    updated_at: new Date().toISOString(),
    last_sync: new Date().toISOString(),
  },
  {
    account_id: 'acc_yt_02',
    user_id: 'usr_default_01',
    platform: 'youtube_shorts',
    account_name: 'AI Secrets Unleashed',
    channel_id: 'UC_AI_Secrets_Official',
    connection_status: 'connected',
    scopes: ['https://www.googleapis.com/auth/youtube.upload'],
    profile_image: 'https://images.unsplash.com/photo-1620712943543-bcc4688e7485?w=150&auto=format&fit=crop&q=80',
    followers_count: 125000,
    created_at: new Date('2026-02-10').toISOString(),
    updated_at: new Date().toISOString(),
    last_sync: new Date().toISOString(),
  },
  {
    account_id: 'acc_tk_01',
    user_id: 'usr_default_01',
    platform: 'tiktok',
    account_name: '@faceless_daily_hacks',
    profile_id: 'tk_user_dailyhacks',
    connection_status: 'connected',
    scopes: ['user.info.basic', 'video.upload', 'video.publish'],
    profile_image: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
    followers_count: 210400,
    created_at: new Date('2026-01-20').toISOString(),
    updated_at: new Date().toISOString(),
    last_sync: new Date().toISOString(),
  },
  {
    account_id: 'acc_fb_01',
    user_id: 'usr_default_01',
    platform: 'facebook_reels',
    account_name: 'Daily Motivation Studio (FB Page)',
    page_id: 'fb_page_8849102',
    connection_status: 'connected',
    scopes: ['pages_show_list', 'pages_read_engagement', 'publish_video'],
    profile_image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
    followers_count: 18900,
    created_at: new Date('2026-02-15').toISOString(),
    updated_at: new Date().toISOString(),
    last_sync: new Date().toISOString(),
  },
  {
    account_id: 'acc_ig_01',
    user_id: 'usr_default_01',
    platform: 'instagram_reels',
    account_name: '@faceless.wealth.hacks',
    profile_id: 'ig_wealth_hacks_9',
    connection_status: 'connected',
    scopes: ['instagram_basic', 'instagram_content_publish'],
    profile_image: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150&auto=format&fit=crop&q=80',
    followers_count: 67300,
    created_at: new Date('2026-02-20').toISOString(),
    updated_at: new Date().toISOString(),
    last_sync: new Date().toISOString(),
  },
  {
    account_id: 'acc_pin_01',
    user_id: 'usr_default_01',
    platform: 'pinterest',
    account_name: 'Faceless Aesthetic Pins',
    profile_id: 'pin_aesthetic_vibes',
    connection_status: 'connected',
    scopes: ['boards:read', 'pins:read', 'pins:write'],
    profile_image: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=150&auto=format&fit=crop&q=80',
    followers_count: 34100,
    created_at: new Date('2026-03-01').toISOString(),
    updated_at: new Date().toISOString(),
    last_sync: new Date().toISOString(),
  },
];

const defaultAIProviders: AIProviderConfig[] = [
  {
    id: 'prov_gemini_01',
    provider: 'google_gemini',
    api_key: process.env.GEMINI_API_KEY || 'AI_STUDIO_INJECTED_KEY',
    default_model: 'gemini-3.6-flash',
    temperature: 0.7,
    max_tokens: 2048,
    image_model: 'gemini-3.1-flash-lite-image',
    voice_model: 'gemini-3.1-flash-tts-preview',
    enabled: true,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  },
  {
    id: 'prov_openai_01',
    provider: 'openai',
    api_key: 'sk-proj-demo-encrypted-key-placeholder',
    default_model: 'gpt-4o-mini',
    temperature: 0.7,
    max_tokens: 2048,
    image_model: 'dall-e-3',
    voice_model: 'tts-1-hd',
    enabled: false,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  },
  {
    id: 'prov_claude_01',
    provider: 'anthropic_claude',
    api_key: 'sk-ant-demo-encrypted-key-placeholder',
    default_model: 'claude-3-5-sonnet-20241022',
    temperature: 0.7,
    max_tokens: 2048,
    image_model: 'sdxl-turbo',
    voice_model: 'elevenlabs-v2',
    enabled: false,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  },
];

const defaultTrends: TrendItem[] = [
  {
    id: 'trend_01',
    keyword: '5 AI Tools Replacing 9-to-5 Jobs in 2026',
    source: 'YouTube Search & TikTok Viral',
    popularity: 98,
    competition: 'Medium',
    category: 'Technology & AI',
    summary: 'High engagement topic showing breakthrough automation tools and productivity workflows for creators.',
    target_audience: 'Entrepreneurs, Freelancers, Tech Enthusiasts',
    fetched_at: new Date().toISOString(),
    expiration: new Date(Date.now() + 86400000 * 7).toISOString(),
  },
  {
    id: 'trend_02',
    keyword: 'The Silent Wealth Trick Banks Don’t Want You To Know',
    source: 'Google Trends & Instagram Reels',
    popularity: 94,
    competition: 'High',
    category: 'Finance & Money',
    summary: 'Personal finance micro-lessons on compound interest, high-yield savings, and index fund strategies.',
    target_audience: 'Gen-Z & Millennial Investors',
    fetched_at: new Date().toISOString(),
    expiration: new Date(Date.now() + 86400000 * 7).toISOString(),
  },
  {
    id: 'trend_03',
    keyword: 'Why Quantum Computers Will Hack Password Encryption',
    source: 'Tech News & Reddit Science',
    popularity: 89,
    competition: 'Low',
    category: 'Cybersecurity & Future',
    summary: 'Explaining quantum cryptography and post-quantum security in 60 seconds with engaging visuals.',
    target_audience: 'Developers, Tech Enthusiasts',
    fetched_at: new Date().toISOString(),
    expiration: new Date(Date.now() + 86400000 * 7).toISOString(),
  },
  {
    id: 'trend_04',
    keyword: '3 Daily Habits That Double Your Focus in 14 Days',
    source: 'TikTok Health & Pinterest Wellness',
    popularity: 91,
    competition: 'Medium',
    category: 'Mindset & Self Improvement',
    summary: 'Dopamine detox routines, circadian lighting tricks, and deep work scheduling for modern creators.',
    target_audience: 'Students, Remote Workers, Professionals',
    fetched_at: new Date().toISOString(),
    expiration: new Date(Date.now() + 86400000 * 7).toISOString(),
  },
];

const defaultProjects: Project[] = [
  {
    id: 'proj_01',
    name: '5 AI Tools You Must Know in 2026',
    topic: '5 AI Tools Replacing 9-to-5 Jobs',
    niche: 'Technology & AI',
    aspect_ratio: '9:16',
    script:
      'Stop scrolling! Here are 5 insanely powerful AI tools that are changing the world in 2026. First, autonomous coding agents that write full apps in seconds. Second, ultra-realistic voice models. Third, instant video generator engines. Save this short so you never lose these tools!',
    title: '5 Crazy AI Tools You Need To Try RIGHT NOW 🚀 #shorts #ai',
    description:
      'Discover the top 5 artificial intelligence tools revolutionizing work and creation in 2026. Save and share with a friend!',
    hashtags: ['#AI', '#TechTrends', '#FacelessAI', '#Automation', '#Shorts'],
    captions: 'Stop scrolling! 5 crazy AI tools changing the game in 2026.',
    thumbnails: ['https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=600&auto=format&fit=crop&q=80'],
    scenes: [
      {
        id: 'sc_1',
        sceneNumber: 1,
        narration: 'Stop scrolling! Here are 5 insanely powerful AI tools changing everything in 2026.',
        visualPrompt: 'Futuristic glowing cybernetic brain with floating holographic screens, ultra detailed digital art',
        imageUrl: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=800&auto=format&fit=crop&q=80',
        duration: 4,
      },
      {
        id: 'sc_2',
        sceneNumber: 2,
        narration: 'First, AI agents building full applications in minutes with voice commands.',
        visualPrompt: 'Futuristic developer workstation with lines of code glowing blue and gold in dark atmosphere',
        imageUrl: 'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?w=800&auto=format&fit=crop&q=80',
        duration: 5,
      },
      {
        id: 'sc_3',
        sceneNumber: 3,
        narration: 'Second, human-like voice synthesis that clones emotion and accent perfectly.',
        visualPrompt: 'Soundwaves transforming into glowing liquid light in high tech audio studio',
        imageUrl: 'https://images.unsplash.com/photo-1598488035139-bdbb2231ce04?w=800&auto=format&fit=crop&q=80',
        duration: 5,
      },
      {
        id: 'sc_4',
        sceneNumber: 4,
        narration: 'Save this video right now so you never miss out on the future of tech!',
        visualPrompt: 'Glowing neon bookmark icon pulsing over high tech geometric background',
        imageUrl: 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?w=800&auto=format&fit=crop&q=80',
        duration: 4,
      },
    ],
    voice_name: 'Kore (Energetic Female)',
    subtitles: [
      { id: 'sub_1', start: 0, end: 2, text: 'Stop scrolling!', highlightWord: 'Stop' },
      { id: 'sub_2', start: 2, end: 4, text: 'Here are 5 insanely powerful AI tools', highlightWord: 'powerful' },
      { id: 'sub_3', start: 4, end: 9, text: 'First, AI agents building full apps', highlightWord: 'agents' },
      { id: 'sub_4', start: 9, end: 14, text: 'Second, human-like voice synthesis', highlightWord: 'voice' },
      { id: 'sub_5', start: 14, end: 18, text: 'Save this video right now!', highlightWord: 'Save' },
    ],
    status: 'generated',
    created_at: new Date('2026-03-10').toISOString(),
    updated_at: new Date().toISOString(),
  },
];

const defaultUploadHistory: UploadHistory[] = [
  {
    id: 'up_01',
    platform: 'youtube_shorts',
    account_id: 'acc_yt_01',
    account_name: 'Tech Mindset Shorts',
    project_id: 'proj_01',
    project_title: '5 Crazy AI Tools You Need To Try RIGHT NOW 🚀',
    upload_date: new Date('2026-03-12T14:30:00Z').toISOString(),
    upload_status: 'success',
    published_time: new Date('2026-03-12T14:30:00Z').toISOString(),
    published_url: 'https://youtube.com/shorts/demo_yt_video_01',
    response_logs: 'Uploaded successfully via YouTube Data API v3. Video ID: demo_yt_video_01',
    retry_count: 0,
  },
  {
    id: 'up_02',
    platform: 'tiktok',
    account_id: 'acc_tk_01',
    account_name: '@faceless_daily_hacks',
    project_id: 'proj_01',
    project_title: '5 Crazy AI Tools You Need To Try RIGHT NOW 🚀',
    upload_date: new Date('2026-03-12T14:35:00Z').toISOString(),
    upload_status: 'success',
    published_time: new Date('2026-03-12T14:35:00Z').toISOString(),
    published_url: 'https://tiktok.com/@faceless_daily_hacks/video/739102839102',
    response_logs: 'Publish request approved by TikTok Creator API. Video ID: 739102839102',
    retry_count: 0,
  },
];

const defaultScheduledPosts: ScheduledPost[] = [
  {
    id: 'sched_01',
    project_id: 'proj_01',
    project_title: '5 Crazy AI Tools You Need To Try RIGHT NOW 🚀',
    target_platform: 'instagram_reels',
    account_id: 'acc_ig_01',
    account_name: '@faceless.wealth.hacks',
    scheduled_time: new Date(Date.now() + 86400000 * 2).toISOString(),
    timezone: 'UTC',
    publishing_workflow: 'auto_publish',
    notification_status: 'pending',
    completion_status: 'scheduled',
    created_at: new Date().toISOString(),
  },
  {
    id: 'sched_02',
    project_id: 'proj_01',
    project_title: '5 Crazy AI Tools You Need To Try RIGHT NOW 🚀',
    target_platform: 'pinterest',
    account_id: 'acc_pin_01',
    account_name: 'Faceless Aesthetic Pins',
    scheduled_time: new Date(Date.now() + 86400000 * 3).toISOString(),
    timezone: 'UTC',
    publishing_workflow: 'notify_and_export',
    notification_status: 'pending',
    completion_status: 'scheduled',
    created_at: new Date().toISOString(),
  },
];

class LocalDatabaseManager {
  private data: DatabaseSchema;

  constructor() {
    this.ensureDirectory();
    this.data = this.loadData();
  }

  private ensureDirectory() {
    if (!fs.existsSync(DB_DIR)) {
      fs.mkdirSync(DB_DIR, { recursive: true });
    }
  }

  private loadData(): DatabaseSchema {
    try {
      if (fs.existsSync(DB_FILE)) {
        const raw = fs.readFileSync(DB_FILE, 'utf-8');
        const parsed = JSON.parse(raw);
        return {
          users: parsed.users || defaultUsers,
          connectedAccounts: parsed.connectedAccounts || defaultConnectedAccounts,
          aiProviders: parsed.aiProviders || defaultAIProviders,
          trendCache: parsed.trendCache || defaultTrends,
          projects: parsed.projects || defaultProjects,
          uploadHistory: parsed.uploadHistory || defaultUploadHistory,
          scheduledPosts: parsed.scheduledPosts || defaultScheduledPosts,
          preferences: parsed.preferences || defaultPreferences,
        };
      }
    } catch (err) {
      console.error('Error reading database file, resetting to defaults:', err);
    }

    const initialData: DatabaseSchema = {
      users: defaultUsers,
      connectedAccounts: defaultConnectedAccounts,
      aiProviders: defaultAIProviders,
      trendCache: defaultTrends,
      projects: defaultProjects,
      uploadHistory: defaultUploadHistory,
      scheduledPosts: defaultScheduledPosts,
      preferences: defaultPreferences,
    };

    this.saveData(initialData);
    return initialData;
  }

  private saveData(data: DatabaseSchema) {
    try {
      this.ensureDirectory();
      fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2), 'utf-8');
    } catch (err) {
      console.error('Error writing to database file:', err);
    }
  }

  public getFullDb(): DatabaseSchema {
    return this.data;
  }

  // Users
  public getUsers(): User[] {
    return this.data.users;
  }

  public getUser(id: string): User | undefined {
    return this.data.users.find((u) => u.user_id === id);
  }

  public updateUser(user: Partial<User> & { user_id: string }): User {
    const index = this.data.users.findIndex((u) => u.user_id === user.user_id);
    if (index >= 0) {
      this.data.users[index] = {
        ...this.data.users[index],
        ...user,
        updated_at: new Date().toISOString(),
      };
    } else {
      const newUser: User = {
        user_id: user.user_id,
        email: user.email || 'user@faceless.studio',
        display_name: user.display_name || 'Creator',
        subscription: user.subscription || 'free',
        preferences: user.preferences || defaultPreferences,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      };
      this.data.users.push(newUser);
    }
    this.saveData(this.data);
    return this.getUser(user.user_id)!;
  }

  // Connected Accounts
  public getConnectedAccounts(): ConnectedAccount[] {
    return this.data.connectedAccounts;
  }

  public saveConnectedAccount(account: ConnectedAccount): ConnectedAccount {
    const idx = this.data.connectedAccounts.findIndex((a) => a.account_id === account.account_id);
    if (idx >= 0) {
      this.data.connectedAccounts[idx] = {
        ...this.data.connectedAccounts[idx],
        ...account,
        updated_at: new Date().toISOString(),
      };
    } else {
      this.data.connectedAccounts.push(account);
    }
    this.saveData(this.data);
    return account;
  }

  public deleteConnectedAccount(accountId: string): boolean {
    const initialLen = this.data.connectedAccounts.length;
    this.data.connectedAccounts = this.data.connectedAccounts.filter((a) => a.account_id !== accountId);
    this.saveData(this.data);
    return this.data.connectedAccounts.length < initialLen;
  }

  // AI Providers
  public getAIProviders(): AIProviderConfig[] {
    return this.data.aiProviders;
  }

  public saveAIProvider(config: AIProviderConfig): AIProviderConfig {
    const idx = this.data.aiProviders.findIndex((p) => p.id === config.id);
    if (idx >= 0) {
      this.data.aiProviders[idx] = {
        ...this.data.aiProviders[idx],
        ...config,
        updated_at: new Date().toISOString(),
      };
    } else {
      this.data.aiProviders.push(config);
    }
    this.saveData(this.data);
    return config;
  }

  // Trends
  public getTrends(): TrendItem[] {
    return this.data.trendCache;
  }

  public setTrends(trends: TrendItem[]) {
    this.data.trendCache = trends;
    this.saveData(this.data);
  }

  // Projects
  public getProjects(): Project[] {
    return this.data.projects;
  }

  public getProject(id: string): Project | undefined {
    return this.data.projects.find((p) => p.id === id);
  }

  public saveProject(project: Project): Project {
    const idx = this.data.projects.findIndex((p) => p.id === project.id);
    if (idx >= 0) {
      this.data.projects[idx] = {
        ...this.data.projects[idx],
        ...project,
        updated_at: new Date().toISOString(),
      };
    } else {
      this.data.projects.push(project);
    }
    this.saveData(this.data);
    return project;
  }

  public deleteProject(id: string): boolean {
    const initialLen = this.data.projects.length;
    this.data.projects = this.data.projects.filter((p) => p.id !== id);
    this.saveData(this.data);
    return this.data.projects.length < initialLen;
  }

  // Upload History
  public getUploadHistory(): UploadHistory[] {
    return this.data.uploadHistory;
  }

  public addUploadRecord(record: UploadHistory): UploadHistory {
    this.data.uploadHistory.unshift(record);
    this.saveData(this.data);
    return record;
  }

  // Scheduled Posts
  public getScheduledPosts(): ScheduledPost[] {
    return this.data.scheduledPosts;
  }

  public saveScheduledPost(post: ScheduledPost): ScheduledPost {
    const idx = this.data.scheduledPosts.findIndex((s) => s.id === post.id);
    if (idx >= 0) {
      this.data.scheduledPosts[idx] = post;
    } else {
      this.data.scheduledPosts.push(post);
    }
    this.saveData(this.data);
    return post;
  }

  public deleteScheduledPost(id: string): boolean {
    const initialLen = this.data.scheduledPosts.length;
    this.data.scheduledPosts = this.data.scheduledPosts.filter((s) => s.id !== id);
    this.saveData(this.data);
    return this.data.scheduledPosts.length < initialLen;
  }

  // Preferences
  public getPreferences(): UserPreferences {
    return this.data.preferences;
  }

  public updatePreferences(prefs: Partial<UserPreferences>): UserPreferences {
    this.data.preferences = {
      ...this.data.preferences,
      ...prefs,
    };
    this.saveData(this.data);
    return this.data.preferences;
  }
}

export const dbManager = new LocalDatabaseManager();
