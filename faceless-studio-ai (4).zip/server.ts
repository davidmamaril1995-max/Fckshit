import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { dbRouter } from './server/routes/dbRoutes.js';
import { aiRouter } from './server/routes/aiRoutes.js';
import { socialRouter } from './server/routes/socialRoutes.js';

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: '50mb' }));
  app.use(express.urlencoded({ extended: true, limit: '50mb' }));

  // API Routes FIRST
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', service: 'Intergalactic Studio AI Backend', timestamp: new Date().toISOString() });
  });

  app.use('/api/db', dbRouter);
  app.use('/api/ai', aiRouter);
  app.use('/api/social', socialRouter);

  // Vite middleware or production static serving
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Faceless Studio AI Server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
