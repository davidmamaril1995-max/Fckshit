import React, { useState, useEffect } from 'react';
import { Header } from './components/Header.tsx';
import { Sidebar } from './components/Sidebar.tsx';
import { Dashboard } from './components/Dashboard.tsx';
import { TrendDiscovery } from './components/TrendDiscovery.tsx';
import { AIPipelineStudio } from './components/AIPipelineStudio.tsx';
import { ProjectsManager } from './components/ProjectsManager.tsx';
import { SocialAccountManager } from './components/SocialAccountManager.tsx';
import { PublisherQueue } from './components/PublisherQueue.tsx';
import { SettingsPanel } from './components/SettingsPanel.tsx';
import { Project, ConnectedAccount, ScheduledPost, TrendItem } from './types.ts';
import { api } from './services/api.ts';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [deviceMode, setDeviceMode] = useState<'phone' | 'tablet' | 'desktop'>('desktop');

  // Database State
  const [projects, setProjects] = useState<Project[]>([]);
  const [accounts, setAccounts] = useState<ConnectedAccount[]>([]);
  const [scheduledPosts, setScheduledPosts] = useState<ScheduledPost[]>([]);

  // Selected Item to pass to studio
  const [selectedTrend, setSelectedTrend] = useState<TrendItem | null>(null);
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);

  const loadData = async () => {
    try {
      const [projs, accs, scheds] = await Promise.all([
        api.getProjects(),
        api.getConnectedAccounts(),
        api.getScheduledPosts(),
      ]);
      setProjects(projs);
      setAccounts(accs);
      setScheduledPosts(scheds);
    } catch (err) {
      console.error('Error loading initial data:', err);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleCreateFromTrend = (trend: TrendItem) => {
    setSelectedTrend(trend);
    setSelectedProject(null);
    setActiveTab('studio');
  };

  const handleOpenProject = (project: Project) => {
    setSelectedProject(project);
    setSelectedTrend(null);
    setActiveTab('studio');
  };

  const handleProjectSaved = async (project: Project) => {
    await api.saveProject(project);
    loadData();
  };

  const handleDeleteProject = async (id: string) => {
    await api.deleteProject(id);
    loadData();
  };

  return (
    <div className="min-h-screen bg-[#090D16] text-gray-100 flex flex-col font-sans selection:bg-indigo-500 selection:text-white">
      {/* Top Header */}
      <Header
        deviceMode={deviceMode}
        setDeviceMode={setDeviceMode}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onQuickCreate={() => {
          setSelectedTrend(null);
          setSelectedProject(null);
          setActiveTab('studio');
        }}
      />

      {/* Main Container */}
      <div className="flex-1 flex overflow-hidden">
        {/* Navigation Sidebar */}
        <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} />

        {/* Dynamic Viewport Wrapper (Handles Phone, Tablet, Desktop Simulation) */}
        <main className="flex-1 overflow-y-auto p-4 md:p-6 lg:p-8">
          {deviceMode === 'phone' ? (
            <div className="max-w-[420px] mx-auto bg-[#0D1117] border-4 border-gray-800 rounded-[40px] shadow-2xl overflow-hidden p-4 min-h-[780px]">
              {renderActiveTab()}
            </div>
          ) : deviceMode === 'tablet' ? (
            <div className="max-w-3xl mx-auto bg-[#0D1117] border-2 border-gray-800 rounded-3xl shadow-2xl p-6 min-h-[700px]">
              {renderActiveTab()}
            </div>
          ) : (
            <div className="max-w-7xl mx-auto">{renderActiveTab()}</div>
          )}
        </main>
      </div>
    </div>
  );

  function renderActiveTab() {
    switch (activeTab) {
      case 'dashboard':
        return (
          <Dashboard
            projects={projects}
            accounts={accounts}
            scheduledPosts={scheduledPosts}
            onNavigate={(tab) => setActiveTab(tab)}
            onOpenProject={handleOpenProject}
          />
        );
      case 'trends':
        return <TrendDiscovery onCreateFromTrend={handleCreateFromTrend} />;
      case 'studio':
        return (
          <AIPipelineStudio
            initialTrend={selectedTrend}
            initialProject={selectedProject}
            connectedAccounts={accounts}
            onProjectSaved={handleProjectSaved}
          />
        );
      case 'projects':
        return (
          <ProjectsManager
            projects={projects}
            onOpenProject={handleOpenProject}
            onDeleteProject={handleDeleteProject}
            onCreateNew={() => {
              setSelectedTrend(null);
              setSelectedProject(null);
              setActiveTab('studio');
            }}
          />
        );
      case 'accounts':
        return <SocialAccountManager accounts={accounts} onAccountsUpdated={loadData} />;
      case 'queue':
        return <PublisherQueue />;
      case 'settings':
        return <SettingsPanel />;
      default:
        return (
          <Dashboard
            projects={projects}
            accounts={accounts}
            scheduledPosts={scheduledPosts}
            onNavigate={(tab) => setActiveTab(tab)}
            onOpenProject={handleOpenProject}
          />
        );
    }
  }
}
