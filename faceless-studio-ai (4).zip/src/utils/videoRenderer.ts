import { Project, SubtitleCue, AspectRatioOption } from '../types.js';

export class CanvasVideoRenderer {
  private canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  private project: Project;
  private loadedImages: Map<string, HTMLImageElement> = new Map();
  private animationFrameId: number | null = null;
  private isPlaying = false;
  private currentTime = 0; // seconds
  private totalDuration = 18; // default duration in seconds
  private mediaRecorder: MediaRecorder | null = null;
  private recordedChunks: Blob[] = [];

  constructor(canvas: HTMLCanvasElement, project: Project) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d')!;
    this.project = project;

    this.calculateDuration();
    this.setCanvasSize(project.aspect_ratio);
    this.preloadImages();
  }

  public updateProject(project: Project) {
    this.project = project;
    this.calculateDuration();
    this.setCanvasSize(project.aspect_ratio);
    this.preloadImages();
  }

  private setCanvasSize(aspectRatio: AspectRatioOption) {
    if (aspectRatio === '9:16') {
      this.canvas.width = 1080;
      this.canvas.height = 1920;
    } else if (aspectRatio === '16:9') {
      this.canvas.width = 1920;
      this.canvas.height = 1080;
    } else {
      this.canvas.width = 1080;
      this.canvas.height = 1080;
    }
  }

  private calculateDuration() {
    if (this.project.scenes && this.project.scenes.length > 0) {
      this.totalDuration = this.project.scenes.reduce((acc, sc) => acc + (sc.duration || 4), 0);
    } else {
      this.totalDuration = 18;
    }
  }

  private preloadImages() {
    if (!this.project.scenes) return;
    this.project.scenes.forEach((sc) => {
      if (sc.imageUrl && !this.loadedImages.has(sc.imageUrl)) {
        const img = new Image();
        img.crossOrigin = 'anonymous';
        img.src = sc.imageUrl;
        img.onload = () => {
          this.loadedImages.set(sc.imageUrl!, img);
        };
      }
    });
  }

  public seek(timeSeconds: number) {
    this.currentTime = Math.max(0, Math.min(timeSeconds, this.totalDuration));
    this.renderFrame();
  }

  public play(onProgress?: (timeSec: number) => void, onEnd?: () => void) {
    if (this.isPlaying) return;
    this.isPlaying = true;
    let lastTime = performance.now();

    const loop = (now: number) => {
      if (!this.isPlaying) return;
      const deltaSec = (now - lastTime) / 1000;
      lastTime = now;

      this.currentTime += deltaSec;
      if (this.currentTime >= this.totalDuration) {
        this.currentTime = 0;
        if (onEnd) onEnd();
      }

      this.renderFrame();
      if (onProgress) onProgress(this.currentTime);

      this.animationFrameId = requestAnimationFrame(loop);
    };

    this.animationFrameId = requestAnimationFrame(loop);
  }

  public pause() {
    this.isPlaying = false;
    if (this.animationFrameId) {
      cancelAnimationFrame(this.animationFrameId);
      this.animationFrameId = null;
    }
  }

  public getTotalDuration(): number {
    return this.totalDuration;
  }

  public getCurrentTime(): number {
    return this.currentTime;
  }

  public renderFrame() {
    const { width, height } = this.canvas;
    const ctx = this.ctx;

    // Clear background
    ctx.fillStyle = '#090D16';
    ctx.fillRect(0, 0, width, height);

    // Identify current scene based on time
    let sceneStartTime = 0;
    let currentScene = this.project.scenes?.[0];
    let sceneDuration = 4;

    if (this.project.scenes && this.project.scenes.length > 0) {
      for (const sc of this.project.scenes) {
        const duration = sc.duration || 4;
        if (this.currentTime >= sceneStartTime && this.currentTime < sceneStartTime + duration) {
          currentScene = sc;
          sceneDuration = duration;
          break;
        }
        sceneStartTime += duration;
      }
    }

    // Render Scene Image with Subtle Ken-Burns Effect
    if (currentScene && currentScene.imageUrl) {
      const img = this.loadedImages.get(currentScene.imageUrl);
      if (img && img.complete) {
        const sceneElapsed = this.currentTime - sceneStartTime;
        const progress = Math.min(1, sceneElapsed / sceneDuration);

        // Zoom scale between 1.0 and 1.12
        const zoom = 1.0 + progress * 0.12;

        ctx.save();
        ctx.translate(width / 2, height / 2);
        ctx.scale(zoom, zoom);

        // Cover fit calculations
        const imgRatio = img.width / img.height;
        const canvasRatio = width / height;
        let renderW = width;
        let renderH = height;

        if (imgRatio > canvasRatio) {
          renderW = height * imgRatio;
        } else {
          renderH = width / imgRatio;
        }

        ctx.drawImage(img, -renderW / 2, -renderH / 2, renderW, renderH);
        ctx.restore();
      } else {
        // Fallback gradient scene if image is loading
        const gradient = ctx.createLinearGradient(0, 0, width, height);
        gradient.addColorStop(0, '#1E1B4B');
        gradient.addColorStop(0.5, '#311042');
        gradient.addColorStop(1, '#0F172A');
        ctx.fillStyle = gradient;
        ctx.fillRect(0, 0, width, height);
      }
    }

    // Dark gradient overlays top and bottom for text contrast
    const topGradient = ctx.createLinearGradient(0, 0, 0, height * 0.25);
    topGradient.addColorStop(0, 'rgba(0,0,0,0.7)');
    topGradient.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = topGradient;
    ctx.fillRect(0, 0, width, height * 0.25);

    const bottomGradient = ctx.createLinearGradient(0, height * 0.65, 0, height);
    bottomGradient.addColorStop(0, 'rgba(0,0,0,0)');
    bottomGradient.addColorStop(1, 'rgba(0,0,0,0.85)');
    ctx.fillStyle = bottomGradient;
    ctx.fillRect(0, height * 0.65, width, height * 0.35);

    // Channel Watermark / Title Badge Top Left
    ctx.fillStyle = 'rgba(255,255,255,0.92)';
    ctx.font = '700 36px "Plus Jakarta Sans", sans-serif';
    ctx.fillText('🌌 INTERGALACTIC AI', 48, 80);

    ctx.fillStyle = 'rgba(255,255,255,0.6)';
    ctx.font = '500 24px "Plus Jakarta Sans", sans-serif';
    ctx.fillText(this.project.name || 'AI Video Blueprint', 48, 120);

    // Render Subtitles
    this.renderSubtitles();

    // Render Bottom Progress Bar
    const progressWidth = (this.currentTime / this.totalDuration) * width;
    ctx.fillStyle = 'rgba(255, 255, 255, 0.2)';
    ctx.fillRect(0, height - 12, width, 12);
    ctx.fillStyle = '#6366F1';
    ctx.fillRect(0, height - 12, progressWidth, 12);
  }

  private renderSubtitles() {
    const { width, height } = this.canvas;
    const ctx = this.ctx;

    // Find active subtitle cue
    const subtitles = this.project.subtitles || [];
    let currentCue: SubtitleCue | undefined;

    if (subtitles.length > 0) {
      currentCue = subtitles.find((sub) => this.currentTime >= sub.start && this.currentTime <= sub.end);
    } else if (this.project.scenes) {
      // Fallback cue from scene narration
      let sceneStartTime = 0;
      for (const sc of this.project.scenes) {
        const duration = sc.duration || 4;
        if (this.currentTime >= sceneStartTime && this.currentTime < sceneStartTime + duration) {
          currentCue = {
            id: `sc_cue_${sc.sceneNumber}`,
            start: sceneStartTime,
            end: sceneStartTime + duration,
            text: sc.narration,
          };
          break;
        }
        sceneStartTime += duration;
      }
    }

    if (!currentCue || !currentCue.text) return;

    const text = currentCue.text.toUpperCase();
    const words = text.split(' ');

    ctx.save();
    ctx.font = '800 52px "Plus Jakarta Sans", sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';

    const centerY = height * 0.78;

    // Draw background pill box for subtitles
    const textWidth = Math.min(width * 0.88, ctx.measureText(text).width + 60);
    const boxHeight = 90;

    ctx.fillStyle = 'rgba(15, 23, 42, 0.85)';
    ctx.strokeStyle = 'rgba(99, 102, 241, 0.5)';
    ctx.lineWidth = 3;

    ctx.beginPath();
    ctx.roundRect(width / 2 - textWidth / 2, centerY - boxHeight / 2, textWidth, boxHeight, 20);
    ctx.fill();
    ctx.stroke();

    // Render subtitle text with glowing highlight
    ctx.fillStyle = '#FFFFFF';
    ctx.shadowColor = '#6366F1';
    ctx.shadowBlur = 12;

    ctx.fillText(text, width / 2, centerY, width * 0.82);
    ctx.restore();
  }

  public exportVideo(): Promise<Blob> {
    return new Promise((resolve, reject) => {
      try {
        const stream = this.canvas.captureStream(30);
        const options = { mimeType: 'video/webm;codecs=vp9' };

        this.recordedChunks = [];
        this.mediaRecorder = new MediaRecorder(
          stream,
          MediaRecorder.isTypeSupported('video/webm;codecs=vp9') ? options : undefined
        );

        this.mediaRecorder.ondataavailable = (event) => {
          if (event.data && event.data.size > 0) {
            this.recordedChunks.push(event.data);
          }
        };

        this.mediaRecorder.onstop = () => {
          const blob = new Blob(this.recordedChunks, { type: 'video/webm' });
          resolve(blob);
        };

        this.currentTime = 0;
        this.mediaRecorder.start();
        this.play(
          undefined,
          () => {
            this.pause();
            if (this.mediaRecorder && this.mediaRecorder.state !== 'inactive') {
              this.mediaRecorder.stop();
            }
          }
        );
      } catch (err) {
        reject(err);
      }
    });
  }
}
