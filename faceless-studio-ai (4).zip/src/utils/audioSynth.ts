export interface VoicePlaybackControl {
  play: () => void;
  pause: () => void;
  stop: () => void;
  onProgress?: (timeSeconds: number) => void;
  onEnded?: () => void;
}

export function speakScript(
  text: string,
  voiceName = 'Kore',
  onWordBoundary?: (charIndex: number, textLength: number, elapsedSec: number) => void,
  onEnd?: () => void
): VoicePlaybackControl {
  if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
    let dummyInterval: any = null;
    let sec = 0;
    return {
      play: () => {
        dummyInterval = setInterval(() => {
          sec += 0.1;
          if (onWordBoundary) onWordBoundary(Math.floor((sec / 15) * text.length), text.length, sec);
          if (sec >= 15) {
            clearInterval(dummyInterval);
            if (onEnd) onEnd();
          }
        }, 100);
      },
      pause: () => clearInterval(dummyInterval),
      stop: () => clearInterval(dummyInterval),
    };
  }

  window.speechSynthesis.cancel();

  const utterance = new SpeechSynthesisUtterance(text);
  utterance.rate = 1.05; // Slightly faster energetic narration pacing
  utterance.pitch = 1.0;

  // Attempt to find matching voice or default
  const voices = window.speechSynthesis.getVoices();
  let selectedVoice = voices.find(
    (v) =>
      v.name.toLowerCase().includes(voiceName.toLowerCase()) ||
      v.name.includes('Google') ||
      v.name.includes('Natural') ||
      v.name.includes('English')
  );
  if (selectedVoice) {
    utterance.voice = selectedVoice;
  }

  let startTime = 0;

  utterance.onboundary = (e) => {
    if (e.name === 'word') {
      const elapsed = (performance.now() - startTime) / 1000;
      if (onWordBoundary) {
        onWordBoundary(e.charIndex, text.length, elapsed);
      }
    }
  };

  utterance.onend = () => {
    if (onEnd) onEnd();
  };

  return {
    play: () => {
      startTime = performance.now();
      window.speechSynthesis.speak(utterance);
    },
    pause: () => {
      window.speechSynthesis.pause();
    },
    stop: () => {
      window.speechSynthesis.cancel();
    },
  };
}
