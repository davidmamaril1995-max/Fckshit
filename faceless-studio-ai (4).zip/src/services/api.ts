import {
  User,
  ConnectedAccount,
  AIProviderConfig,
  TrendItem,
  Project,
  UploadHistory,
  ScheduledPost,
  UserPreferences,
  ScriptPipelineRequest,
  ScriptPipelineResponse,
  SocialPlatform,
} from '../types.js';

export const api = {
  // Database API
  getUsers: async (): Promise<User[]> => {
    const res = await fetch('/api/db/users');
    const data = await res.json();
    return data.users || [];
  },

  getConnectedAccounts: async (): Promise<ConnectedAccount[]> => {
    const res = await fetch('/api/db/connected-accounts');
    const data = await res.json();
    return data.accounts || [];
  },

  saveConnectedAccount: async (acc: ConnectedAccount): Promise<ConnectedAccount> => {
    const res = await fetch('/api/db/connected-accounts', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(acc),
    });
    const data = await res.json();
    return data.account;
  },

  deleteConnectedAccount: async (id: string): Promise<boolean> => {
    const res = await fetch(`/api/db/connected-accounts/${id}`, { method: 'DELETE' });
    const data = await res.json();
    return data.success;
  },

  getAIProviders: async (): Promise<AIProviderConfig[]> => {
    const res = await fetch('/api/db/ai-providers');
    const data = await res.json();
    return data.providers || [];
  },

  saveAIProvider: async (config: AIProviderConfig): Promise<AIProviderConfig> => {
    const res = await fetch('/api/db/ai-providers', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(config),
    });
    const data = await res.json();
    return data.provider;
  },

  getProjects: async (): Promise<Project[]> => {
    const res = await fetch('/api/db/projects');
    const data = await res.json();
    return data.projects || [];
  },

  saveProject: async (project: Project): Promise<Project> => {
    const res = await fetch('/api/db/projects', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(project),
    });
    const data = await res.json();
    return data.project;
  },

  deleteProject: async (id: string): Promise<boolean> => {
    const res = await fetch(`/api/db/projects/${id}`, { method: 'DELETE' });
    const data = await res.json();
    return data.success;
  },

  getUploadHistory: async (): Promise<UploadHistory[]> => {
    const res = await fetch('/api/db/upload-history');
    const data = await res.json();
    return data.history || [];
  },

  getScheduledPosts: async (): Promise<ScheduledPost[]> => {
    const res = await fetch('/api/db/scheduled-posts');
    const data = await res.json();
    return data.scheduledPosts || [];
  },

  saveScheduledPost: async (post: ScheduledPost): Promise<ScheduledPost> => {
    const res = await fetch('/api/db/scheduled-posts', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(post),
    });
    const data = await res.json();
    return data.scheduledPost;
  },

  deleteScheduledPost: async (id: string): Promise<boolean> => {
    const res = await fetch(`/api/db/scheduled-posts/${id}`, { method: 'DELETE' });
    const data = await res.json();
    return data.success;
  },

  getPreferences: async (): Promise<UserPreferences> => {
    const res = await fetch('/api/db/preferences');
    const data = await res.json();
    return data.preferences;
  },

  updatePreferences: async (prefs: Partial<UserPreferences>): Promise<UserPreferences> => {
    const res = await fetch('/api/db/preferences', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(prefs),
    });
    const data = await res.json();
    return data.preferences;
  },

  // AI Pipeline API
  generateScript: async (payload: ScriptPipelineRequest & { scriptEngine?: string }): Promise<ScriptPipelineResponse> => {
    const res = await fetch('/api/ai/generate-script', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    const data = await res.json();
    return data.data;
  },

  generateSceneImage: async (prompt: string, aspectRatio = '9:16', imageEngine = 'gemini_imagen_3'): Promise<string> => {
    const res = await fetch('/api/ai/generate-image', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ prompt, aspectRatio, imageEngine }),
    });
    const data = await res.json();
    return data.imageUrl || 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=800&auto=format&fit=crop&q=80';
  },

  generateVoiceTTS: async (
    text: string,
    voiceName = 'Adam (ElevenLabs Deep Gravitas)',
    voiceEngine = 'elevenlabs',
    stability = 0.75,
    clarity = 0.85
  ): Promise<{ audioDataUrl?: string; useWebSpeechFallback?: boolean; provider?: string }> => {
    const res = await fetch('/api/ai/generate-voice', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text, voiceName, voiceEngine, stability, clarity }),
    });
    return res.json();
  },

  getTrends: async (): Promise<TrendItem[]> => {
    const res = await fetch('/api/ai/trends');
    const data = await res.json();
    return data.trends || [];
  },

  // Social Media API
  getAuthUrl: async (platform: string): Promise<{ url: string; platform: string }> => {
    const res = await fetch(`/api/social/auth/url?platform=${encodeURIComponent(platform)}`);
    return res.json();
  },

  loginSocialAccount: async (payload: {
    platform: SocialPlatform;
    email?: string;
    password?: string;
    username?: string;
    channel_name?: string;
    auth_code?: string;
  }): Promise<ConnectedAccount> => {
    const res = await fetch('/api/social/login-account', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    const data = await res.json();
    return data.account;
  },

  connectSocialAccount: async (payload: {
    platform: SocialPlatform;
    account_name: string;
    channel_id?: string;
    page_id?: string;
    profile_id?: string;
  }): Promise<ConnectedAccount> => {
    const res = await fetch('/api/social/connect-account', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    const data = await res.json();
    return data.account;
  },

  refreshAccount: async (accountId: string): Promise<ConnectedAccount> => {
    const res = await fetch(`/api/social/refresh-account/${accountId}`, { method: 'POST' });
    const data = await res.json();
    return data.account;
  },

  publishProject: async (payload: {
    projectId: string;
    accountId?: string;
    platform?: SocialPlatform;
    scheduledTime?: string;
  }): Promise<{ message: string }> => {
    const res = await fetch('/api/social/publish-project', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    return res.json();
  },
};
