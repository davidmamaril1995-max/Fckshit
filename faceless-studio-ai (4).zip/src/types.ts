export type AIProviderName =
  | 'elevenlabs'
  | 'google_gemini'
  | 'openai'
  | 'anthropic_claude'
  | 'deepseek'
  | 'midjourney'
  | 'stable_diffusion';

export interface ElevenLabsVoiceSettings {
  stability: number; // 0 to 1
  similarity_boost: number; // 0 to 1
  style: number; // 0 to 1
  use_speaker_boost: boolean;
}

export interface AIModelOptions {
  scriptEngine: 'gemini_3_6_flash' | 'gpt_4o' | 'claude_3_5_sonnet' | 'deepseek_v3';
  imageEngine: 'gemini_imagen_3' | 'midjourney_v6' | 'stable_diffusion_3_5' | 'dalle_3';
  voiceEngine: 'elevenlabs' | 'gemini_tts' | 'openai_tts' | 'web_speech';
  elevenLabsVoiceId?: string;
  elevenLabsSettings?: ElevenLabsVoiceSettings;
}

export type SocialPlatform =
  | 'youtube_shorts'
  | 'tiktok'
  | 'facebook_reels'
  | 'instagram_reels'
  | 'threads'
  | 'pinterest';

export type AspectRatioOption = '9:16' | '16:9' | '1:1';

export type ProjectStatus = 'draft' | 'scripted' | 'generated' | 'scheduled' | 'published';

export interface UserPreferences {
  user_id: string;
  theme: 'system' | 'dark' | 'light';
  dark_mode: boolean;
  language: string;
  default_ai_provider: 'google_gemini' | 'openai' | 'anthropic_claude';
  preferred_voice: string;
  preferred_aspect_ratio: AspectRatioOption;
  export_settings: {
    resolution: '1080p' | '720p' | '4k';
    fps: number;
    format: 'mp4' | 'webm';
  };
  video_quality: 'high' | 'medium' | 'draft';
  subtitle_preferences: {
    fontFamily: string;
    fontSize: number;
    fontColor: string;
    backgroundColor: string;
    position: 'bottom' | 'middle' | 'top';
    animation: 'pop' | 'typewriter' | 'glow' | 'standard';
  };
}

export interface User {
  user_id: string;
  email: string;
  display_name: string;
  subscription: 'free' | 'creator_pro' | 'studio_enterprise';
  preferences: UserPreferences;
  created_at: string;
  updated_at: string;
}

export interface ConnectedAccount {
  account_id: string;
  user_id: string;
  platform: SocialPlatform;
  account_name: string;
  channel_id?: string;
  profile_id?: string;
  page_id?: string;
  connection_status: 'connected' | 'expired' | 'disconnected' | 'error';
  access_token?: string;
  refresh_token?: string;
  token_expiration?: string;
  scopes: string[];
  profile_image?: string;
  followers_count?: number;
  created_at: string;
  updated_at: string;
  last_sync: string;
}

export interface AIProviderConfig {
  id: string;
  provider: 'google_gemini' | 'openai' | 'anthropic_claude';
  api_key: string;
  default_model: string;
  temperature: number;
  max_tokens: number;
  image_model: string;
  voice_model: string;
  enabled: boolean;
  created_at: string;
  updated_at: string;
}

export interface TrendItem {
  id: string;
  keyword: string;
  source: string;
  popularity: number; // 0 - 100
  competition: 'Low' | 'Medium' | 'High';
  category: string;
  summary?: string;
  target_audience?: string;
  fetched_at: string;
  expiration: string;
}

export interface SubtitleCue {
  id: string;
  start: number; // in seconds
  end: number; // in seconds
  text: string;
  highlightWord?: string;
}

export interface ProjectScene {
  id: string;
  sceneNumber: number;
  narration: string;
  visualPrompt: string;
  imageUrl?: string;
  duration: number; // in seconds
}

export interface Project {
  id: string;
  name: string;
  topic: string;
  niche: string;
  aspect_ratio: AspectRatioOption;
  script: string;
  title: string;
  description: string;
  hashtags: string[];
  captions: string;
  thumbnails: string[];
  scenes: ProjectScene[];
  voice_url?: string;
  voice_name: string;
  subtitles: SubtitleCue[];
  video_url?: string;
  bg_music_url?: string;
  status: ProjectStatus;
  created_at: string;
  updated_at: string;
}

export interface UploadHistory {
  id: string;
  platform: SocialPlatform;
  account_id: string;
  account_name: string;
  project_id: string;
  project_title: string;
  upload_date: string;
  upload_status: 'success' | 'failed' | 'processing' | 'queued';
  scheduled_time?: string;
  published_time?: string;
  published_url?: string;
  response_logs: string;
  retry_count: number;
  error_messages?: string;
}

export interface ScheduledPost {
  id: string;
  project_id: string;
  project_title: string;
  target_platform: SocialPlatform;
  account_id: string;
  account_name: string;
  scheduled_time: string;
  timezone: string;
  publishing_workflow: 'auto_publish' | 'notify_and_export' | 'manual_review';
  notification_status: 'pending' | 'sent' | 'read';
  completion_status: 'scheduled' | 'in_progress' | 'completed' | 'failed' | 'cancelled';
  created_at: string;
}

export interface ScriptPipelineRequest {
  topic: string;
  niche: string;
  tone?: string;
  targetDurationSeconds?: number;
  aspectRatio?: AspectRatioOption;
  targetPlatform?: SocialPlatform;
}

export interface ScriptPipelineResponse {
  script: string;
  title: string;
  description: string;
  hashtags: string[];
  captions: string;
  scenes: Array<{
    sceneNumber: number;
    narration: string;
    visualPrompt: string;
    suggestedDuration: number;
  }>;
}
