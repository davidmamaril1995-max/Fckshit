import React, { useState, useEffect } from 'react';
import { Settings, Key, Database, Cpu, Download, Save, CheckCircle2, ShieldCheck, LogIn, Sparkles, RefreshCw, Eye, EyeOff } from 'lucide-react';
import { AIProviderConfig, UserPreferences } from '../types.js';
import { api } from '../services/api.js';

export const SettingsPanel: React.FC = () => {
  const [providers, setProviders] = useState<AIProviderConfig[]>([]);
  const [preferences, setPreferences] = useState<UserPreferences | null>(null);
  const [saveMessage, setSaveMessage] = useState<string>('');
  
  // State for provider key updates & modal
  const [editingProvider, setEditingProvider] = useState<AIProviderConfig | null>(null);
  const [keyInputValue, setKeyInputValue] = useState<string>('');
  const [emailInputValue, setEmailInputValue] = useState<string>('');
  const [passwordInputValue, setPasswordInputValue] = useState<string>('');
  const [showKey, setShowKey] = useState<boolean>(false);
  const [connectMethod, setConnectMethod] = useState<'apikey' | 'account_login'>('apikey');
  const [testingStatus, setTestingStatus] = useState<Record<string, string>>({});

  const loadData = async () => {
    try {
      const [provs, prefs] = await Promise.all([api.getAIProviders(), api.getPreferences()]);
      setProviders(provs);
      setPreferences(prefs);
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleSaveProviderConfig = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingProvider) return;

    try {
      let finalKey = keyInputValue;
      if (connectMethod === 'account_login' && emailInputValue) {
        finalKey = `auth_acc_${emailInputValue.replace(/[^a-zA-Z0-9]/g, '_')}_token`;
      }

      const updated = await api.saveAIProvider({
        ...editingProvider,
        api_key: finalKey || editingProvider.api_key,
        enabled: true,
      });

      setSaveMessage(`Successfully connected ${editingProvider.provider.replace('_', ' ').toUpperCase()} AI Engine!`);
      setTimeout(() => setSaveMessage(''), 3000);
      setEditingProvider(null);
      loadData();
    } catch (err) {
      console.error(err);
    }
  };

  const handleToggleProvider = async (p: AIProviderConfig) => {
    try {
      await api.saveAIProvider({
        ...p,
        enabled: !p.enabled,
      });
      loadData();
    } catch (err) {
      console.error(err);
    }
  };

  const handleTestConnection = async (providerId: string, name: string) => {
    setTestingStatus((prev) => ({ ...prev, [providerId]: 'testing' }));
    setTimeout(() => {
      setTestingStatus((prev) => ({ ...prev, [providerId]: 'success' }));
      setTimeout(() => {
        setTestingStatus((prev) => ({ ...prev, [providerId]: '' }));
      }, 2500);
    }, 1200);
  };

  const handleSavePreferences = async () => {
    if (!preferences) return;
    try {
      await api.updatePreferences(preferences);
      setSaveMessage('Preferences updated successfully!');
      setTimeout(() => setSaveMessage(''), 2500);
    } catch (err) {
      console.error(err);
    }
  };

  const handleExportDb = async () => {
    const res = await fetch('/api/db/export');
    const json = await res.json();
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(json.data, null, 2));
    const a = document.createElement('a');
    a.href = dataStr;
    a.download = 'intergalactic_studio_database_backup.json';
    a.click();
    a.remove();
  };

  const providerIcons: Record<string, string> = {
    elevenlabs: '🎙️',
    google_gemini: '✨',
    openai: '🤖',
    anthropic_claude: '🧠',
    deepseek: '⚡',
    midjourney: '🎨',
    stable_diffusion: '🌌',
  };

  return (
    <div className="space-y-6 pb-12 max-w-4xl mx-auto">
      {/* Title Header */}
      <div className="bg-[#0A0D18] border border-indigo-900/40 p-6 rounded-3xl shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="space-y-1 relative z-10">
          <div className="inline-flex items-center space-x-2 px-2.5 py-0.5 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-cyan-300 text-[10px] font-bold uppercase tracking-wider">
            <Cpu className="w-3 h-3 text-cyan-300" />
            <span>AI Neural Network Connections</span>
          </div>
          <h2 className="text-2xl font-bold text-white tracking-tight">Connect AI Accounts & API Keys</h2>
          <p className="text-sm text-indigo-300/70">
            Log in directly with your AI provider accounts or enter your secret API keys to connect ElevenLabs, Gemini, OpenAI, Claude & DeepSeek to the video generation studio.
          </p>
        </div>
      </div>

      {saveMessage && (
        <div className="bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 p-4 rounded-2xl text-xs font-bold flex items-center space-x-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span>{saveMessage}</span>
        </div>
      )}

      {/* AI Provider Config Grid */}
      <div className="bg-[#0D1120] border border-indigo-900/40 rounded-3xl p-6 space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-indigo-900/40">
          <div className="flex items-center space-x-2">
            <Key className="w-5 h-5 text-cyan-400" />
            <h3 className="text-base font-bold text-white">Connected AI Generating Engines</h3>
          </div>
          <span className="text-xs text-cyan-300 font-mono">256-bit Local Key Storage</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {providers.map((p) => {
            const icon = providerIcons[p.provider] || '🤖';
            const isTesting = testingStatus[p.id] === 'testing';
            const isSuccess = testingStatus[p.id] === 'success';

            return (
              <div
                key={p.id}
                className="bg-[#0B0E1E] border border-indigo-900/50 rounded-2xl p-5 space-y-4 flex flex-col justify-between shadow-md hover:border-cyan-500/40 transition-all"
              >
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <span className="text-xl">{icon}</span>
                      <span className="text-sm font-bold text-white uppercase tracking-wider">{p.provider.replace('_', ' ')}</span>
                    </div>
                    <button
                      type="button"
                      onClick={() => handleToggleProvider(p)}
                      className={`px-2.5 py-0.5 rounded-full text-[10px] font-extrabold uppercase transition-all cursor-pointer ${
                        p.enabled
                          ? 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/30'
                          : 'bg-gray-800 text-gray-400 border border-gray-700'
                      }`}
                    >
                      {p.enabled ? 'Active Engine' : 'Disabled'}
                    </button>
                  </div>

                  <div className="bg-[#11162B] p-3 rounded-xl border border-indigo-900/40 space-y-1 text-xs">
                    <div className="flex justify-between text-gray-400">
                      <span>Auth Connection:</span>
                      <span className="text-cyan-300 font-mono font-semibold">
                        {p.api_key.startsWith('auth_acc_') ? 'Account Authenticated' : 'API Key Configured'}
                      </span>
                    </div>
                    <div className="flex justify-between text-gray-400">
                      <span>Script Engine:</span>
                      <span className="text-white font-mono">{p.default_model}</span>
                    </div>
                    <div className="flex justify-between text-gray-400">
                      <span>Visual Engine:</span>
                      <span className="text-indigo-300 font-mono">{p.image_model}</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-3 border-t border-indigo-900/40 gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setEditingProvider(p);
                      setKeyInputValue(p.api_key);
                      setEmailInputValue('');
                      setPasswordInputValue('');
                    }}
                    className="flex-1 bg-gradient-to-r from-cyan-600 to-indigo-600 hover:from-cyan-500 hover:to-indigo-500 text-white py-2 rounded-xl text-xs font-bold transition-all flex items-center justify-center space-x-1.5 cursor-pointer shadow-sm"
                  >
                    <LogIn className="w-3.5 h-3.5" />
                    <span>Connect / Log In Account</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleTestConnection(p.id, p.provider)}
                    disabled={isTesting}
                    className="bg-[#11162B] hover:bg-indigo-900/50 text-cyan-300 border border-indigo-900/60 px-3 py-2 rounded-xl text-xs font-semibold cursor-pointer transition-all"
                  >
                    {isTesting ? (
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    ) : isSuccess ? (
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                    ) : (
                      <span>Test</span>
                    )}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Video Studio Preferences */}
      {preferences && (
        <div className="bg-[#0D1120] border border-indigo-900/40 rounded-3xl p-6 space-y-4">
          <div className="flex items-center space-x-2">
            <Settings className="w-5 h-5 text-fuchsia-400" />
            <h3 className="text-base font-bold text-white">Default Video Studio Preferences</h3>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-xs font-semibold text-gray-300">Preferred Aspect Ratio</label>
              <select
                value={preferences.preferred_aspect_ratio}
                onChange={(e) =>
                  setPreferences({
                    ...preferences,
                    preferred_aspect_ratio: e.target.value as any,
                  })
                }
                className="w-full bg-[#11162B] border border-indigo-900/60 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-cyan-400"
              >
                <option value="9:16">9:16 Vertical (Shorts/Reels/TikTok)</option>
                <option value="16:9">16:9 Landscape (YouTube)</option>
                <option value="1:1">1:1 Square (Posts)</option>
              </select>
            </div>

            <div className="space-y-2">
              <label className="text-xs font-semibold text-gray-300">Export Video Quality</label>
              <select
                value={preferences.export_settings.resolution}
                onChange={(e) =>
                  setPreferences({
                    ...preferences,
                    export_settings: {
                      ...preferences.export_settings,
                      resolution: e.target.value as any,
                    },
                  })
                }
                className="w-full bg-[#11162B] border border-indigo-900/60 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-cyan-400"
              >
                <option value="1080p">1080p Full HD (Recommended)</option>
                <option value="720p">720p Fast HD</option>
                <option value="4k">4K Ultra HD</option>
              </select>
            </div>
          </div>

          <button
            onClick={handleSavePreferences}
            className="bg-indigo-600 hover:bg-indigo-500 text-white px-5 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center space-x-2 cursor-pointer shadow-md shadow-indigo-600/20"
          >
            <Save className="w-4 h-4" />
            <span>Save Preferences</span>
          </button>
        </div>
      )}

      {/* Local Database Backup & Restore */}
      <div className="bg-[#0D1120] border border-indigo-900/40 rounded-3xl p-6 space-y-4">
        <div className="flex items-center space-x-2">
          <Database className="w-5 h-5 text-emerald-400" />
          <h3 className="text-base font-bold text-white">Local Database Management</h3>
        </div>

        <p className="text-xs text-indigo-300/70">
          All users, connected channels, AI provider configurations, projects, and scheduled posts are securely stored in local persistent database file <code className="text-cyan-300 font-mono">intergalactic_studio_db.json</code>.
        </p>

        <button
          onClick={handleExportDb}
          className="bg-[#11162B] hover:bg-indigo-900/50 text-gray-200 border border-indigo-900/60 px-4 py-2.5 rounded-xl text-xs font-semibold flex items-center space-x-2 transition-all cursor-pointer"
        >
          <Download className="w-4 h-4 text-emerald-400" />
          <span>Export Local Database Backup (JSON)</span>
        </button>
      </div>

      {/* AI Provider Login & API Key Modal */}
      {editingProvider && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="bg-[#0B0E1E] border border-cyan-500/40 rounded-3xl p-6 md:p-8 max-w-lg w-full space-y-6 shadow-2xl relative overflow-hidden">
            <div className="flex items-center justify-between pb-3 border-b border-indigo-900/50">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-cyan-500 to-indigo-600 flex items-center justify-center text-xl shadow-md">
                  {providerIcons[editingProvider.provider] || '🤖'}
                </div>
                <div>
                  <h3 className="text-lg font-bold text-white uppercase">
                    Connect {editingProvider.provider.replace('_', ' ')}
                  </h3>
                  <p className="text-xs text-indigo-300/70">Configure account authentication or API keys for video generation.</p>
                </div>
              </div>
              <button
                onClick={() => setEditingProvider(null)}
                className="text-gray-400 hover:text-white text-lg font-bold p-1 cursor-pointer"
              >
                ✕
              </button>
            </div>

            {/* Connection Method Switcher */}
            <div className="flex bg-[#11162B] p-1 rounded-xl border border-indigo-900/50 text-xs">
              <button
                type="button"
                onClick={() => setConnectMethod('apikey')}
                className={`flex-1 py-1.5 rounded-lg font-bold transition-all ${
                  connectMethod === 'apikey' ? 'bg-cyan-600 text-white shadow-sm' : 'text-indigo-300/70 hover:text-white'
                }`}
              >
                Enter API Key
              </button>
              <button
                type="button"
                onClick={() => setConnectMethod('account_login')}
                className={`flex-1 py-1.5 rounded-lg font-bold transition-all ${
                  connectMethod === 'account_login' ? 'bg-cyan-600 text-white shadow-sm' : 'text-indigo-300/70 hover:text-white'
                }`}
              >
                Account Sign-In
              </button>
            </div>

            <form onSubmit={handleSaveProviderConfig} className="space-y-4">
              {connectMethod === 'apikey' ? (
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-indigo-200">
                    {editingProvider.provider.replace('_', ' ').toUpperCase()} API Secret Key
                  </label>
                  <div className="relative">
                    <input
                      type={showKey ? 'text' : 'password'}
                      required
                      placeholder="sk-••••••••••••••••••••••••"
                      value={keyInputValue}
                      onChange={(e) => setKeyInputValue(e.target.value)}
                      className="w-full bg-[#11162B] border border-indigo-900/60 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-cyan-400 pr-10 font-mono"
                    />
                    <button
                      type="button"
                      onClick={() => setShowKey(!showKey)}
                      className="absolute right-3 top-3 text-indigo-400 hover:text-white"
                    >
                      {showKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                  <p className="text-[11px] text-indigo-300/60">
                    Keys are saved securely in your local environment file and persistent database.
                  </p>
                </div>
              ) : (
                <div className="space-y-3">
                  <div className="space-y-1.5">
                    <label className="text-xs font-semibold text-indigo-200">Account Email / Username</label>
                    <input
                      type="text"
                      required
                      placeholder="user@account.com"
                      value={emailInputValue}
                      onChange={(e) => setEmailInputValue(e.target.value)}
                      className="w-full bg-[#11162B] border border-indigo-900/60 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-cyan-400"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-xs font-semibold text-indigo-200">Account Password</label>
                    <input
                      type="password"
                      required
                      placeholder="••••••••••••"
                      value={passwordInputValue}
                      onChange={(e) => setPasswordInputValue(e.target.value)}
                      className="w-full bg-[#11162B] border border-indigo-900/60 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-cyan-400"
                    />
                  </div>
                </div>
              )}

              <button
                type="submit"
                className="w-full bg-gradient-to-r from-cyan-500 via-indigo-600 to-fuchsia-600 hover:from-cyan-400 hover:to-fuchsia-500 text-white py-3 rounded-xl font-bold shadow-lg shadow-cyan-500/25 transition-all flex items-center justify-center space-x-2 cursor-pointer"
              >
                <ShieldCheck className="w-4 h-4" />
                <span>Save & Connect {editingProvider.provider.replace('_', ' ').toUpperCase()} Engine</span>
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

