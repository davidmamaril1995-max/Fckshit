import React, { useState, useEffect } from 'react';
import { Share2, Plus, RefreshCw, Trash2, CheckCircle2, Lock, ExternalLink, ShieldCheck, LogIn, Globe } from 'lucide-react';
import { ConnectedAccount, SocialPlatform } from '../types.js';
import { api } from '../services/api.js';

interface SocialAccountManagerProps {
  accounts: ConnectedAccount[];
  onAccountsUpdated: () => void;
}

export const SocialAccountManager: React.FC<SocialAccountManagerProps> = ({ accounts, onAccountsUpdated }) => {
  const [showConnectModal, setShowConnectModal] = useState<boolean>(false);
  const [platform, setPlatform] = useState<SocialPlatform>('youtube_shorts');
  const [email, setEmail] = useState<string>('');
  const [password, setPassword] = useState<string>('');
  const [channelName, setChannelName] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(false);
  const [loginMethod, setLoginMethod] = useState<'credentials' | 'oauth_popup'>('credentials');

  useEffect(() => {
    const handleMessage = (event: MessageEvent) => {
      if (event.data && event.data.type === 'OAUTH_AUTH_SUCCESS') {
        onAccountsUpdated();
        setShowConnectModal(false);
      }
    };
    window.addEventListener('message', handleMessage);
    return () => window.removeEventListener('message', handleMessage);
  }, [onAccountsUpdated]);

  const platformMeta: Record<
    SocialPlatform,
    { name: string; color: string; badgeBg: string; logo: string; placeholder: string; defaultName: string }
  > = {
    youtube_shorts: {
      name: 'YouTube Shorts',
      color: 'from-red-600 to-rose-700',
      badgeBg: 'bg-red-500/15 text-red-400 border-red-500/30',
      logo: '▶',
      placeholder: 'user@gmail.com',
      defaultName: 'Intergalactic Shorts HD',
    },
    tiktok: {
      name: 'TikTok Creator',
      color: 'from-cyan-500 via-teal-500 to-pink-500',
      badgeBg: 'bg-cyan-500/15 text-cyan-300 border-cyan-500/30',
      logo: '🎵',
      placeholder: '@creator_handle',
      defaultName: 'Cosmic TikTok AI',
    },
    instagram_reels: {
      name: 'Instagram Reels',
      color: 'from-fuchsia-600 via-pink-600 to-amber-500',
      badgeBg: 'bg-fuchsia-500/15 text-fuchsia-300 border-fuchsia-500/30',
      logo: '📸',
      placeholder: 'instagram_username',
      defaultName: 'Intergalactic Reels',
    },
    facebook_reels: {
      name: 'Facebook Page',
      color: 'from-blue-600 to-indigo-700',
      badgeBg: 'bg-blue-500/15 text-blue-300 border-blue-500/30',
      logo: 'f',
      placeholder: 'fb_page_admin@gmail.com',
      defaultName: 'Intergalactic Media Page',
    },
    threads: {
      name: 'Threads Profile',
      color: 'from-gray-700 to-black',
      badgeBg: 'bg-indigo-500/15 text-indigo-300 border-indigo-500/30',
      logo: '@',
      placeholder: 'threads_handle',
      defaultName: 'Cosmic Threads Feed',
    },
    pinterest: {
      name: 'Pinterest Business',
      color: 'from-rose-600 to-red-700',
      badgeBg: 'bg-rose-500/15 text-rose-300 border-rose-500/30',
      logo: '📌',
      placeholder: 'punterest_business_email',
      defaultName: 'Galactic Pins Studio',
    },
  };

  const handleAccountLogin = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setLoading(true);
    try {
      await api.loginSocialAccount({
        platform,
        email,
        password,
        channel_name: channelName || platformMeta[platform].defaultName,
      });
      onAccountsUpdated();
      setShowConnectModal(false);
      setEmail('');
      setPassword('');
      setChannelName('');
    } catch (err) {
      console.error('Account login error:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleLaunchPopupOAuth = async () => {
    try {
      setLoading(true);
      const res = await api.getAuthUrl(platform);
      const authWindow = window.open(res.url, 'oauth_popup', 'width=600,height=700');
      if (!authWindow) {
        alert('Please allow popup windows in your browser settings to perform account OAuth authorization.');
      }
    } catch (err) {
      console.error('OAuth popup error:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleRefresh = async (id: string) => {
    try {
      await api.refreshAccount(id);
      onAccountsUpdated();
    } catch (err) {
      console.error(err);
    }
  };

  const handleDelete = async (id: string) => {
    try {
      await api.deleteConnectedAccount(id);
      onAccountsUpdated();
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Title Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-[#0A0D18] border border-indigo-900/40 p-6 rounded-3xl shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="space-y-1 relative z-10">
          <div className="inline-flex items-center space-x-2 px-2.5 py-0.5 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-cyan-300 text-[10px] font-bold uppercase tracking-wider">
            <Globe className="w-3 h-3 text-cyan-300" />
            <span>Multi-Galactic Social Publisher</span>
          </div>
          <h2 className="text-2xl font-bold text-white tracking-tight">Authenticated Social Channels</h2>
          <p className="text-sm text-indigo-300/70">
            Log in directly with your accounts across YouTube, TikTok, Instagram, Facebook, Pinterest & Threads for automated 1-click video publishing.
          </p>
        </div>
        <button
          onClick={() => setShowConnectModal(true)}
          className="bg-gradient-to-r from-cyan-500 via-indigo-600 to-fuchsia-600 hover:from-cyan-400 hover:to-fuchsia-500 text-white px-5 py-2.5 rounded-xl text-xs font-semibold flex items-center space-x-2 transition-all cursor-pointer shadow-lg shadow-cyan-500/20 active:scale-95"
        >
          <LogIn className="w-4 h-4" />
          <span>Log In & Connect Channel</span>
        </button>
      </div>

      {/* Account Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {accounts.map((acc) => {
          const meta = platformMeta[acc.platform] || platformMeta.youtube_shorts;
          return (
            <div
              key={acc.account_id}
              className="bg-[#0D1120] border border-indigo-900/40 rounded-2xl p-5 space-y-4 flex flex-col justify-between shadow-lg hover:border-cyan-500/40 transition-all group"
            >
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className={`px-2.5 py-1 border rounded-lg text-xs font-bold uppercase ${meta.badgeBg}`}>
                    {meta.logo} {acc.platform.replace('_', ' ')}
                  </span>
                  <span className="flex items-center space-x-1.5 text-xs text-cyan-300 font-semibold bg-cyan-500/10 border border-cyan-500/30 px-2 py-0.5 rounded-full">
                    <ShieldCheck className="w-3.5 h-3.5 text-cyan-400" />
                    <span>Authenticated</span>
                  </span>
                </div>

                <div className="flex items-center space-x-3">
                  <img
                    src={acc.profile_image}
                    alt={acc.account_name}
                    className="w-12 h-12 rounded-full object-cover border-2 border-indigo-500/40 shadow-md"
                  />
                  <div>
                    <h4 className="text-sm font-bold text-white group-hover:text-cyan-200 transition-colors">
                      {acc.account_name}
                    </h4>
                    <p className="text-xs text-cyan-400 font-medium">
                      {(acc.followers_count || 0).toLocaleString()} Subscribers/Followers
                    </p>
                  </div>
                </div>

                <div className="text-[11px] text-indigo-300/60 space-y-1 pt-2 border-t border-indigo-900/40 font-mono">
                  <div>ID: {acc.channel_id || acc.page_id || acc.profile_id || 'acc_default'}</div>
                  <div>Token State: Valid (OAuth 2.0)</div>
                  <div>Last Sync: {new Date(acc.last_sync).toLocaleString()}</div>
                </div>
              </div>

              <div className="flex items-center justify-between pt-3 border-t border-indigo-900/40">
                <button
                  onClick={() => handleRefresh(acc.account_id)}
                  className="text-xs text-indigo-300 hover:text-white flex items-center space-x-1.5 cursor-pointer"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>Refresh Token</span>
                </button>

                <button
                  onClick={() => handleDelete(acc.account_id)}
                  className="text-xs text-rose-400 hover:text-rose-300 flex items-center space-x-1 cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Disconnect</span>
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Account Login OAuth Portal Modal */}
      {showConnectModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="bg-[#0B0E1E] border border-cyan-500/40 rounded-3xl p-6 md:p-8 max-w-lg w-full space-y-6 shadow-2xl relative overflow-hidden">
            <div className="absolute -top-20 -right-20 w-48 h-48 bg-cyan-500/20 rounded-full blur-2xl pointer-events-none" />

            <div className="flex items-center justify-between pb-3 border-b border-indigo-900/50">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-cyan-500 to-fuchsia-600 flex items-center justify-center text-white font-bold text-lg shadow-md">
                  {platformMeta[platform].logo}
                </div>
                <div>
                  <h3 className="text-lg font-bold text-white">Log In & Authorize {platformMeta[platform].name}</h3>
                  <p className="text-xs text-indigo-300/70">Connect your account using real OAuth or account sign-in</p>
                </div>
              </div>
              <button
                onClick={() => setShowConnectModal(false)}
                className="text-gray-400 hover:text-white text-lg font-bold p-1 cursor-pointer"
              >
                ✕
              </button>
            </div>

            {/* Helper Tip */}
            <div className="bg-cyan-500/10 border border-cyan-500/20 p-3 rounded-xl text-xs text-cyan-200 flex items-start space-x-2">
              <ShieldCheck className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
              <div>
                <strong className="text-white block font-semibold">Direct Authentication Active:</strong>
                Use <strong>Sign In With Credentials</strong> or the <strong>OAuth Popup Portal</strong> below to connect your YouTube/social channel directly without needing a Google Cloud registered Client ID.
              </div>
            </div>

            {/* Platform Selector Tabs */}
            <div className="space-y-2">
              <label className="text-xs font-semibold text-indigo-200">Select Platform Channel</label>
              <div className="grid grid-cols-3 gap-2">
                {(Object.keys(platformMeta) as SocialPlatform[]).map((p) => (
                  <button
                    key={p}
                    type="button"
                    onClick={() => setPlatform(p)}
                    className={`p-2.5 rounded-xl text-xs font-bold transition-all border flex items-center justify-center space-x-1.5 cursor-pointer ${
                      platform === p
                        ? 'bg-gradient-to-r from-cyan-600 to-indigo-600 text-white border-cyan-400/50 shadow-md'
                        : 'bg-[#11162B] border-indigo-900/50 text-indigo-300/70 hover:text-white'
                    }`}
                  >
                    <span>{platformMeta[p].logo}</span>
                    <span className="truncate">{platformMeta[p].name.split(' ')[0]}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Login Method Toggle */}
            <div className="flex bg-[#11162B] p-1 rounded-xl border border-indigo-900/50 text-xs">
              <button
                type="button"
                onClick={() => setLoginMethod('credentials')}
                className={`flex-1 py-1.5 rounded-lg font-bold transition-all ${
                  loginMethod === 'credentials' ? 'bg-cyan-600 text-white shadow-sm' : 'text-indigo-300/70 hover:text-white'
                }`}
              >
                Sign In With Credentials
              </button>
              <button
                type="button"
                onClick={() => setLoginMethod('oauth_popup')}
                className={`flex-1 py-1.5 rounded-lg font-bold transition-all ${
                  loginMethod === 'oauth_popup' ? 'bg-cyan-600 text-white shadow-sm' : 'text-indigo-300/70 hover:text-white'
                }`}
              >
                OAuth Popup Portal
              </button>
            </div>

            {loginMethod === 'credentials' ? (
              <form onSubmit={handleAccountLogin} className="space-y-4">
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-indigo-200">Account Email / Username</label>
                  <input
                    type="text"
                    required
                    placeholder={platformMeta[platform].placeholder}
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full bg-[#11162B] border border-indigo-900/60 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-cyan-400"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-indigo-200">Account Password</label>
                  <div className="relative">
                    <input
                      type="password"
                      required
                      placeholder="••••••••••••"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="w-full bg-[#11162B] border border-indigo-900/60 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-cyan-400 pr-10"
                    />
                    <Lock className="w-4 h-4 text-indigo-400 absolute right-3 top-3" />
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-indigo-200">Channel / Brand Display Name</label>
                  <input
                    type="text"
                    placeholder={platformMeta[platform].defaultName}
                    value={channelName}
                    onChange={(e) => setChannelName(e.target.value)}
                    className="w-full bg-[#11162B] border border-indigo-900/60 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-cyan-400"
                  />
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full bg-gradient-to-r from-cyan-500 via-indigo-600 to-fuchsia-600 hover:from-cyan-400 hover:to-fuchsia-500 text-white py-3 rounded-xl font-bold shadow-lg shadow-cyan-500/25 transition-all flex items-center justify-center space-x-2 cursor-pointer disabled:opacity-50"
                >
                  <LogIn className="w-4 h-4" />
                  <span>{loading ? 'Authenticating Account...' : `Authorize & Log In ${platformMeta[platform].name}`}</span>
                </button>
              </form>
            ) : (
              <div className="space-y-4 text-center py-2">
                <p className="text-xs text-indigo-200/80 leading-relaxed">
                  Clicking the button below will trigger a secure OAuth authorization popup for{' '}
                  <strong className="text-cyan-300">{platformMeta[platform].name}</strong> asking for content posting permissions.
                </p>

                <button
                  onClick={handleLaunchPopupOAuth}
                  disabled={loading}
                  className="w-full bg-gradient-to-r from-cyan-500 to-indigo-600 hover:from-cyan-400 hover:to-indigo-500 text-white py-3 rounded-xl font-bold shadow-lg shadow-cyan-500/20 transition-all flex items-center justify-center space-x-2 cursor-pointer"
                >
                  <ExternalLink className="w-4 h-4" />
                  <span>Open Official OAuth Popup Window</span>
                </button>
              </div>
            )}

            <div className="flex items-center space-x-2 text-[11px] text-cyan-300/80 bg-cyan-500/10 p-3 rounded-xl border border-cyan-500/20">
              <ShieldCheck className="w-4 h-4 text-cyan-400 shrink-0" />
              <span>
                Tokens are stored locally in <code className="text-white font-mono">intergalactic_studio_db.json</code> with 256-bit encryption.
              </span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
