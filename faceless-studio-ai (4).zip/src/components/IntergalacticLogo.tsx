import React from 'react';

interface LogoProps {
  size?: 'sm' | 'md' | 'lg';
  showText?: boolean;
}

export const IntergalacticLogo: React.FC<LogoProps> = ({ size = 'md', showText = true }) => {
  const sizeClasses = {
    sm: { container: 'w-8 h-8', icon: 'w-4 h-4', text: 'text-sm', badge: 'text-[9px]' },
    md: { container: 'w-10 h-10', icon: 'w-5 h-5', text: 'text-lg', badge: 'text-[10px]' },
    lg: { container: 'w-14 h-14', icon: 'w-7 h-7', text: 'text-2xl', badge: 'text-xs' },
  }[size];

  return (
    <div className="flex items-center space-x-3 select-none">
      <div
        className={`${sizeClasses.container} rounded-2xl bg-gradient-to-br from-cyan-400 via-indigo-600 to-fuchsia-600 p-[1.5px] shadow-lg shadow-cyan-500/25 relative group overflow-hidden`}
      >
        <div className="w-full h-full bg-[#080B18] rounded-[14px] flex items-center justify-center relative overflow-hidden">
          {/* Cosmic Nebula Glow */}
          <div className="absolute inset-0 bg-gradient-to-tr from-cyan-500/30 via-indigo-500/20 to-fuchsia-500/30 group-hover:opacity-100 transition-opacity" />
          
          {/* Animated Planet Orbit SVG */}
          <svg
            className={`${sizeClasses.icon} text-cyan-200 relative z-10 animate-spin-slow`}
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="1.75"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <circle cx="12" cy="12" r="5" className="fill-cyan-400/20 stroke-cyan-300" />
            <ellipse cx="12" cy="12" rx="9" ry="3.5" transform="rotate(-30 12 12)" className="stroke-fuchsia-400" />
            <circle cx="17" cy="9" r="1.2" className="fill-cyan-200 stroke-none animate-pulse" />
            <circle cx="7" cy="15" r="0.8" className="fill-fuchsia-200 stroke-none" />
          </svg>
        </div>
      </div>

      {showText && (
        <div className="flex flex-col">
          <div className="flex items-center space-x-2">
            <span className={`font-extrabold tracking-tight text-transparent bg-clip-text bg-gradient-to-r from-cyan-300 via-indigo-100 to-fuchsia-300 ${sizeClasses.text}`}>
              INTERGALACTIC
            </span>
            <span className={`px-2 py-0.5 font-bold bg-cyan-500/15 text-cyan-300 border border-cyan-500/30 rounded-full tracking-widest uppercase ${sizeClasses.badge}`}>
              AI
            </span>
          </div>
          <span className="text-[10px] font-medium text-indigo-300/70 tracking-wider uppercase">
            Cosmic Video Engine & Studio
          </span>
        </div>
      )}
    </div>
  );
};
