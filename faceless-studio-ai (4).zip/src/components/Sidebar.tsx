import React from 'react';
import {
  LayoutDashboard,
  TrendingUp,
  Wand2,
  FileVideo,
  Share2,
  CalendarCheck,
  Settings,
  ChevronRight,
} from 'lucide-react';

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ activeTab, setActiveTab }) => {
  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard, badge: undefined },
    { id: 'trends', label: 'Trend Discovery', icon: TrendingUp, badge: 'Live' },
    { id: 'studio', label: 'AI Video Studio', icon: Wand2, badge: 'Gemini' },
    { id: 'projects', label: 'Content Projects', icon: FileVideo, badge: undefined },
    { id: 'accounts', label: 'Connected Accounts', icon: Share2, badge: '6 Connected' },
    { id: 'queue', label: 'Publisher Queue', icon: CalendarCheck, badge: undefined },
    { id: 'settings', label: 'AI & Database Config', icon: Settings, badge: undefined },
  ];

  return (
    <>
      {/* Desktop & Tablet Sidebar */}
      <aside className="w-64 bg-[#0A0D18] border-r border-indigo-900/40 hidden md:flex flex-col justify-between p-4 min-h-[calc(100vh-65px)]">
        <div className="space-y-1">
          <div className="px-3 py-2 text-[11px] font-bold text-indigo-400/70 uppercase tracking-widest">
            Cosmic Workflows
          </div>
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-sm font-medium transition-all cursor-pointer ${
                  isActive
                    ? 'bg-gradient-to-r from-cyan-500/15 via-indigo-600/20 to-fuchsia-600/15 text-cyan-300 border border-cyan-500/30'
                    : 'text-gray-400 hover:text-white hover:bg-indigo-950/40'
                }`}
              >
                <div className="flex items-center space-x-3">
                  <Icon className={`w-4 h-4 ${isActive ? 'text-cyan-300' : 'text-gray-400'}`} />
                  <span>{item.label}</span>
                </div>
                {item.badge && (
                  <span
                    className={`px-2 py-0.5 text-[10px] font-bold rounded-full ${
                      isActive ? 'bg-cyan-500/20 text-cyan-200 border border-cyan-500/30' : 'bg-gray-800 text-gray-400'
                    }`}
                  >
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Engine Status Card */}
        <div className="bg-gradient-to-b from-[#11162B] to-[#0A0D18] border border-indigo-900/50 rounded-2xl p-3.5 space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-indigo-200">Intergalactic Engine</span>
            <span className="text-[10px] font-bold text-cyan-300 bg-cyan-500/10 px-2 py-0.5 rounded-full border border-cyan-500/30">
              Cosmic Online
            </span>
          </div>
          <div className="w-full bg-indigo-950 h-1.5 rounded-full overflow-hidden">
            <div className="bg-gradient-to-r from-cyan-400 via-indigo-500 to-fuchsia-500 h-full w-full rounded-full" />
          </div>
          <p className="text-[11px] text-indigo-300/70">Gemini 3.6 Flash + Cosmic Image & Voice Synthesizers active.</p>
        </div>
      </aside>

      {/* Mobile Bottom Navigation Bar */}
      <div className="md:hidden fixed bottom-0 left-0 right-0 bg-[#0A0D18] border-t border-indigo-900/60 px-2 py-1.5 flex items-center justify-around z-50 overflow-x-auto shadow-2xl">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`flex flex-col items-center justify-center space-y-1 px-2.5 py-1.5 rounded-xl text-xs font-medium cursor-pointer shrink-0 transition-all ${
                isActive
                  ? 'text-cyan-300 bg-cyan-500/15 border border-cyan-500/30 font-bold'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              <Icon className={`w-4 h-4 ${isActive ? 'text-cyan-300' : 'text-gray-400'}`} />
              <span className="text-[10px] whitespace-nowrap">
                {item.id === 'settings' ? 'AI Keys' : item.id === 'accounts' ? 'Channels' : item.label.split(' ')[0]}
              </span>
            </button>
          );
        })}
      </div>
    </>
  );
};
