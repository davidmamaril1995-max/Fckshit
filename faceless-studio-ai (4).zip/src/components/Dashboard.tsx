import React from 'react';
import {
  TrendingUp,
  Video,
  Share2,
  CalendarCheck,
  Sparkles,
  ArrowRight,
  Clock,
  CheckCircle2,
  Youtube,
  Play,
} from 'lucide-react';
import { Project, ConnectedAccount, ScheduledPost, SocialPlatform } from '../types.js';

interface DashboardProps {
  projects: Project[];
  accounts: ConnectedAccount[];
  scheduledPosts: ScheduledPost[];
  onNavigate: (tab: string) => void;
  onOpenProject: (project: Project) => void;
}

export const Dashboard: React.FC<DashboardProps> = ({
  projects,
  accounts,
  scheduledPosts,
  onNavigate,
  onOpenProject,
}) => {
  const publishedCount = projects.filter((p) => p.status === 'published').length;
  const scheduledCount = scheduledPosts.filter((s) => s.completion_status === 'scheduled').length;

  return (
    <div className="space-y-6 pb-12">
      {/* Hero Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-cyan-950/60 via-indigo-950/50 to-fuchsia-950/40 border border-cyan-500/30 p-6 md:p-8 shadow-2xl">
        <div className="absolute -top-24 -right-24 w-72 h-72 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 max-w-2xl space-y-3">
          <div className="inline-flex items-center space-x-2 bg-cyan-500/10 border border-cyan-500/30 px-3 py-1 rounded-full text-xs font-semibold text-cyan-300">
            <Sparkles className="w-3.5 h-3.5 text-cyan-300" />
            <span>Intergalactic Production Engine</span>
          </div>
          <h2 className="text-2xl md:text-3xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-white via-cyan-100 to-indigo-200 tracking-tight">
            Generate, Render & Launch Intergalactic Short Videos Across the Galaxy
          </h2>
          <p className="text-sm text-indigo-200/80 leading-relaxed">
            Automate short-form cosmic scripts, AI image rendering, natural speech synthesis, and multi-channel publishing to YouTube Shorts, TikTok, Reels & Pinterest.
          </p>
          <div className="pt-2 flex flex-wrap gap-3">
            <button
              onClick={() => onNavigate('studio')}
              className="bg-gradient-to-r from-cyan-500 via-indigo-600 to-fuchsia-600 hover:from-cyan-400 hover:to-fuchsia-500 text-white px-5 py-2.5 rounded-xl text-sm font-semibold shadow-lg shadow-cyan-500/25 transition-all flex items-center space-x-2 cursor-pointer"
            >
              <Sparkles className="w-4 h-4" />
              <span>Launch AI Video Studio</span>
            </button>
            <button
              onClick={() => onNavigate('trends')}
              className="bg-[#11162B] hover:bg-indigo-950 text-cyan-200 border border-cyan-500/30 px-5 py-2.5 rounded-xl text-sm font-semibold transition-all flex items-center space-x-2 cursor-pointer"
            >
              <TrendingUp className="w-4 h-4 text-cyan-400" />
              <span>Explore Galactic Trends</span>
            </button>
          </div>
        </div>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-[#0D1117] border border-gray-800 rounded-2xl p-4 space-y-2">
          <div className="flex items-center justify-between text-gray-400">
            <span className="text-xs font-medium">Total Projects</span>
            <Video className="w-4 h-4 text-indigo-400" />
          </div>
          <div className="text-2xl font-bold text-white">{projects.length}</div>
          <p className="text-[11px] text-gray-400">{publishedCount} published across social channels</p>
        </div>

        <div className="bg-[#0D1117] border border-gray-800 rounded-2xl p-4 space-y-2">
          <div className="flex items-center justify-between text-gray-400">
            <span className="text-xs font-medium">Connected Accounts</span>
            <Share2 className="w-4 h-4 text-purple-400" />
          </div>
          <div className="text-2xl font-bold text-white">{accounts.length}</div>
          <p className="text-[11px] text-emerald-400 font-medium">Multi-platform channels active</p>
        </div>

        <div className="bg-[#0D1117] border border-gray-800 rounded-2xl p-4 space-y-2">
          <div className="flex items-center justify-between text-gray-400">
            <span className="text-xs font-medium">Scheduled Posts</span>
            <CalendarCheck className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-2xl font-bold text-white">{scheduledCount}</div>
          <p className="text-[11px] text-gray-400">Queue ready for automated upload</p>
        </div>

        <div className="bg-[#0D1117] border border-gray-800 rounded-2xl p-4 space-y-2">
          <div className="flex items-center justify-between text-gray-400">
            <span className="text-xs font-medium">Est. Monthly Reach</span>
            <TrendingUp className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-bold text-emerald-400">485.2K</div>
          <p className="text-[11px] text-gray-400">+34% vs previous 30 days</p>
        </div>
      </div>

      {/* Connected Channels Grid */}
      <div className="bg-[#0D1117] border border-gray-800 rounded-2xl p-5 space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-base font-bold text-white">Connected Social Accounts</h3>
            <p className="text-xs text-gray-400">Automated publishing destination channels</p>
          </div>
          <button
            onClick={() => onNavigate('accounts')}
            className="text-xs font-semibold text-indigo-400 hover:text-indigo-300 flex items-center space-x-1 cursor-pointer"
          >
            <span>Manage All ({accounts.length})</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {accounts.map((acc) => (
            <div
              key={acc.account_id}
              className="bg-gray-900/70 border border-gray-800 rounded-xl p-3.5 flex items-center space-x-3 hover:border-gray-700 transition-all"
            >
              <img
                src={acc.profile_image}
                alt={acc.account_name}
                className="w-10 h-10 rounded-full object-cover border border-gray-700"
              />
              <div className="flex-1 min-w-0">
                <div className="flex items-center space-x-1.5">
                  <span className="text-xs font-bold text-white truncate">{acc.account_name}</span>
                </div>
                <div className="flex items-center space-x-2 text-[11px] text-gray-400 mt-0.5">
                  <span className="capitalize">{acc.platform.replace('_', ' ')}</span>
                  <span>•</span>
                  <span className="text-indigo-300">{(acc.followers_count || 0).toLocaleString()} followers</span>
                </div>
              </div>
              <span className="w-2 h-2 rounded-full bg-emerald-400 flex-shrink-0" />
            </div>
          ))}
        </div>
      </div>

      {/* Recent Projects List */}
      <div className="bg-[#0D1117] border border-gray-800 rounded-2xl p-5 space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-base font-bold text-white">Recent Faceless Video Projects</h3>
            <p className="text-xs text-gray-400">Created and generated AI video blueprints</p>
          </div>
          <button
            onClick={() => onNavigate('projects')}
            className="text-xs font-semibold text-indigo-400 hover:text-indigo-300 flex items-center space-x-1 cursor-pointer"
          >
            <span>View All Library</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {projects.slice(0, 3).map((proj) => (
            <div
              key={proj.id}
              onClick={() => onOpenProject(proj)}
              className="group bg-gray-900/60 border border-gray-800 hover:border-indigo-500/50 rounded-2xl overflow-hidden transition-all duration-200 cursor-pointer flex flex-col justify-between"
            >
              <div>
                <div className="relative aspect-video bg-gray-950 overflow-hidden">
                  <img
                    src={proj.thumbnails?.[0] || 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=600&auto=format&fit=crop&q=80'}
                    alt={proj.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                    <div className="w-10 h-10 rounded-full bg-indigo-600 text-white flex items-center justify-center shadow-lg">
                      <Play className="w-5 h-5 fill-current ml-0.5" />
                    </div>
                  </div>
                  <div className="absolute top-2 left-2 bg-black/70 backdrop-blur-md px-2 py-0.5 rounded-md text-[10px] font-bold text-indigo-300 border border-white/10">
                    {proj.aspect_ratio}
                  </div>
                  <div className="absolute top-2 right-2 bg-emerald-500/20 backdrop-blur-md px-2 py-0.5 rounded-md text-[10px] font-bold text-emerald-300 border border-emerald-500/30 uppercase">
                    {proj.status}
                  </div>
                </div>
                <div className="p-4 space-y-2">
                  <h4 className="text-sm font-bold text-white group-hover:text-indigo-300 line-clamp-1">
                    {proj.title || proj.name}
                  </h4>
                  <p className="text-xs text-gray-400 line-clamp-2">{proj.script}</p>
                </div>
              </div>
              <div className="p-4 pt-0 flex items-center justify-between text-xs text-gray-500 border-t border-gray-800/50 mt-2 pt-3">
                <span>Niche: {proj.niche}</span>
                <span>{proj.scenes?.length || 0} Scenes</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
