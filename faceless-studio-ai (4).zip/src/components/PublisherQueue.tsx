import React, { useState, useEffect } from 'react';
import { CalendarCheck, History, CheckCircle2, Clock, AlertTriangle, RefreshCw, Trash2 } from 'lucide-react';
import { UploadHistory, ScheduledPost } from '../types.js';
import { api } from '../services/api.js';

export const PublisherQueue: React.FC = () => {
  const [history, setHistory] = useState<UploadHistory[]>([]);
  const [scheduled, setScheduled] = useState<ScheduledPost[]>([]);
  const [loading, setLoading] = useState<boolean>(true);

  const loadQueueData = async () => {
    setLoading(true);
    try {
      const [histData, schedData] = await Promise.all([api.getUploadHistory(), api.getScheduledPosts()]);
      setHistory(histData);
      setScheduled(schedData);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadQueueData();
  }, []);

  const handleDeleteSchedule = async (id: string) => {
    try {
      await api.deleteScheduledPost(id);
      loadQueueData();
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Title Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-[#0D1117] border border-gray-800 p-6 rounded-3xl">
        <div>
          <h2 className="text-2xl font-bold text-white tracking-tight">Publisher & Scheduling Queue</h2>
          <p className="text-sm text-gray-400">Automated post publication schedule and response status logs.</p>
        </div>
        <button
          onClick={loadQueueData}
          className="bg-gray-800 hover:bg-gray-700 text-gray-200 border border-gray-700 px-4 py-2.5 rounded-xl text-xs font-semibold flex items-center space-x-2 transition-all cursor-pointer"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
          <span>Refresh Queue</span>
        </button>
      </div>

      {/* Scheduled Posts Timeline */}
      <div className="bg-[#0D1117] border border-gray-800 rounded-3xl p-6 space-y-4">
        <div className="flex items-center space-x-2">
          <Clock className="w-5 h-5 text-indigo-400" />
          <h3 className="text-base font-bold text-white">Upcoming Scheduled Uploads</h3>
        </div>

        {scheduled.length === 0 ? (
          <p className="text-xs text-gray-400 italic">No upcoming scheduled posts in queue.</p>
        ) : (
          <div className="space-y-3">
            {scheduled.map((item) => (
              <div
                key={item.id}
                className="bg-gray-900 border border-gray-800 rounded-2xl p-4 flex flex-col md:flex-row md:items-center justify-between gap-4"
              >
                <div className="space-y-1">
                  <div className="flex items-center space-x-2">
                    <span className="px-2.5 py-0.5 bg-indigo-500/10 text-indigo-400 text-[10px] font-bold rounded-md uppercase">
                      {item.target_platform.replace('_', ' ')}
                    </span>
                    <span className="text-xs font-bold text-white">{item.project_title}</span>
                  </div>
                  <p className="text-xs text-gray-400">Target Channel: {item.account_name}</p>
                </div>

                <div className="flex items-center space-x-4">
                  <div className="text-right">
                    <div className="text-xs font-bold text-amber-400">
                      {new Date(item.scheduled_time).toLocaleString()}
                    </div>
                    <div className="text-[10px] text-gray-500">Workflow: {item.publishing_workflow}</div>
                  </div>

                  <button
                    onClick={() => handleDeleteSchedule(item.id)}
                    className="text-gray-500 hover:text-rose-400 p-2 rounded-lg transition-colors cursor-pointer"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Upload History Logs */}
      <div className="bg-[#0D1117] border border-gray-800 rounded-3xl p-6 space-y-4">
        <div className="flex items-center space-x-2">
          <History className="w-5 h-5 text-emerald-400" />
          <h3 className="text-base font-bold text-white">Publishing Response Logs</h3>
        </div>

        <div className="space-y-3">
          {history.map((log) => (
            <div key={log.id} className="bg-gray-900 border border-gray-800 rounded-2xl p-4 space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-white">{log.project_title}</span>
                <span
                  className={`px-2 py-0.5 rounded-md text-[10px] font-bold uppercase ${
                    log.upload_status === 'success'
                      ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                      : 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                  }`}
                >
                  {log.upload_status}
                </span>
              </div>
              <p className="text-xs text-gray-300 font-mono bg-black/40 p-2.5 rounded-xl border border-gray-800/80">
                {log.response_logs}
              </p>
              <div className="flex items-center justify-between text-[11px] text-gray-500">
                <span>Platform: {log.platform} ({log.account_name})</span>
                <span>Date: {new Date(log.upload_date).toLocaleString()}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
