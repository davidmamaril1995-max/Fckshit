import React, { useState, useEffect } from 'react';
import { TrendingUp, Sparkles, Search, RefreshCw, Flame, BarChart3, ArrowRight } from 'lucide-react';
import { TrendItem } from '../types.js';
import { api } from '../services/api.js';

interface TrendDiscoveryProps {
  onCreateFromTrend: (trend: TrendItem) => void;
}

export const TrendDiscovery: React.FC<TrendDiscoveryProps> = ({ onCreateFromTrend }) => {
  const [trends, setTrends] = useState<TrendItem[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');

  const categories = ['All', 'Technology & AI', 'Finance & Money', 'Cybersecurity & Future', 'Mindset & Self Improvement'];

  const fetchTrends = async () => {
    setLoading(true);
    try {
      const data = await api.getTrends();
      setTrends(data);
    } catch (err) {
      console.error('Failed to fetch trends:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTrends();
  }, []);

  const filteredTrends = trends.filter((t) => {
    const matchesCategory = selectedCategory === 'All' || t.category === selectedCategory;
    const matchesSearch =
      t.keyword.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.summary?.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="space-y-6 pb-12">
      {/* Title Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-[#0D1117] border border-gray-800 p-6 rounded-3xl">
        <div>
          <div className="flex items-center space-x-2 text-indigo-400 text-xs font-bold uppercase tracking-wider mb-1">
            <Flame className="w-4 h-4 text-amber-500" />
            <span>Social Media Trend Radar</span>
          </div>
          <h2 className="text-2xl font-bold text-white tracking-tight">Viral Topic & Trend Discovery</h2>
          <p className="text-sm text-gray-400">
            Real-time viral topics scraped from search trends and short-form platforms ready for instant faceless video generation.
          </p>
        </div>
        <button
          onClick={fetchTrends}
          disabled={loading}
          className="bg-gray-800 hover:bg-gray-700 text-gray-200 border border-gray-700 px-4 py-2.5 rounded-xl text-xs font-semibold flex items-center space-x-2 transition-all cursor-pointer disabled:opacity-50"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin text-indigo-400' : ''}`} />
          <span>Refresh Live Radar</span>
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 text-gray-400 absolute left-3.5 top-3" />
          <input
            type="text"
            placeholder="Search viral keywords or niches..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-[#0D1117] border border-gray-800 rounded-xl pl-10 pr-4 py-2 text-sm text-white focus:outline-none focus:border-indigo-500 placeholder-gray-500"
          />
        </div>

        <div className="flex items-center space-x-2 overflow-x-auto w-full sm:w-auto pb-2 sm:pb-0">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3.5 py-2 rounded-xl text-xs font-medium whitespace-nowrap transition-all cursor-pointer ${
                selectedCategory === cat
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/20'
                  : 'bg-[#0D1117] text-gray-400 border border-gray-800 hover:text-white'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Trend Cards Grid */}
      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="bg-[#0D1117] border border-gray-800 rounded-2xl p-6 h-48 animate-pulse" />
          ))}
        </div>
      ) : filteredTrends.length === 0 ? (
        <div className="bg-[#0D1117] border border-gray-800 rounded-3xl p-12 text-center space-y-3">
          <TrendingUp className="w-10 h-10 text-gray-600 mx-auto" />
          <h3 className="text-base font-bold text-white">No trends found for this filter</h3>
          <p className="text-xs text-gray-400">Try searching for a different keyword or category.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredTrends.map((trend) => (
            <div
              key={trend.id}
              className="bg-[#0D1117] border border-gray-800 hover:border-indigo-500/50 rounded-2xl p-5 space-y-4 transition-all duration-200 flex flex-col justify-between"
            >
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="px-2.5 py-1 bg-indigo-500/10 border border-indigo-500/20 text-indigo-300 rounded-lg text-xs font-semibold">
                    {trend.category}
                  </span>
                  <div className="flex items-center space-x-2">
                    <span className="text-xs text-gray-400">{trend.source}</span>
                    <span
                      className={`px-2 py-0.5 text-[10px] font-bold rounded-md uppercase ${
                        trend.competition === 'Low'
                          ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                          : trend.competition === 'Medium'
                          ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                          : 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                      }`}
                    >
                      {trend.competition} Competition
                    </span>
                  </div>
                </div>

                <h3 className="text-lg font-bold text-white hover:text-indigo-300 transition-colors">
                  {trend.keyword}
                </h3>

                <p className="text-xs text-gray-300 leading-relaxed">{trend.summary}</p>
              </div>

              <div className="pt-3 border-t border-gray-800/60 space-y-3">
                {/* Popularity Bar */}
                <div className="space-y-1">
                  <div className="flex items-center justify-between text-xs text-gray-400">
                    <span className="flex items-center space-x-1">
                      <BarChart3 className="w-3.5 h-3.5 text-indigo-400" />
                      <span>Viral Score</span>
                    </span>
                    <span className="font-bold text-indigo-400">{trend.popularity}/100</span>
                  </div>
                  <div className="w-full bg-gray-800 h-2 rounded-full overflow-hidden">
                    <div
                      className="bg-gradient-to-r from-indigo-500 to-purple-500 h-full rounded-full"
                      style={{ width: `${trend.popularity}%` }}
                    />
                  </div>
                </div>

                <button
                  onClick={() => onCreateFromTrend(trend)}
                  className="w-full bg-indigo-600 hover:bg-indigo-500 text-white py-2.5 rounded-xl text-xs font-bold transition-all flex items-center justify-center space-x-2 cursor-pointer shadow-md shadow-indigo-600/20"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Create AI Video Blueprint From Trend</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
