import React from 'react';
import { Smartphone, Tablet, Monitor, Rocket } from 'lucide-react';
import { IntergalacticLogo } from './IntergalacticLogo';

interface HeaderProps {
  deviceMode: 'phone' | 'tablet' | 'desktop';
  setDeviceMode: (mode: 'phone' | 'tablet' | 'desktop') => void;
  activeTab: string;
  setActiveTab?: (tab: string) => void;
  onQuickCreate: () => void;
}

export const Header: React.FC<HeaderProps> = ({ deviceMode, setDeviceMode, activeTab, setActiveTab, onQuickCreate }) => {
  return (
    <header className="bg-[#0A0D18] border-b border-indigo-900/40 px-4 py-3 sticky top-0 z-50 flex items-center justify-between">
      <IntergalacticLogo size="md" />

      {/* Device Viewport Selector for Mobile & Tablet Responsiveness */}
      <div className="hidden md:flex items-center bg-[#11162B] border border-indigo-900/50 rounded-xl p-1 space-x-1">
        <button
          onClick={() => setDeviceMode('phone')}
          className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
            deviceMode === 'phone'
              ? 'bg-gradient-to-r from-cyan-600 to-indigo-600 text-white shadow-md shadow-cyan-500/20'
              : 'text-gray-400 hover:text-white'
          }`}
        >
          <Smartphone className="w-3.5 h-3.5" />
          <span>Phone (9:16)</span>
        </button>
        <button
          onClick={() => setDeviceMode('tablet')}
          className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
            deviceMode === 'tablet'
              ? 'bg-gradient-to-r from-cyan-600 to-indigo-600 text-white shadow-md shadow-cyan-500/20'
              : 'text-gray-400 hover:text-white'
          }`}
        >
          <Tablet className="w-3.5 h-3.5" />
          <span>Tablet</span>
        </button>
        <button
          onClick={() => setDeviceMode('desktop')}
          className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
            deviceMode === 'desktop'
              ? 'bg-gradient-to-r from-cyan-600 to-indigo-600 text-white shadow-md shadow-cyan-500/20'
              : 'text-gray-400 hover:text-white'
          }`}
        >
          <Monitor className="w-3.5 h-3.5" />
          <span>Desktop</span>
        </button>
      </div>

      <div className="flex items-center space-x-1.5 sm:space-x-3">
        {setActiveTab && (
          <div className="flex items-center space-x-1 sm:space-x-2 border-r border-indigo-900/50 pr-2 sm:pr-3 mr-0.5 sm:mr-1">
            <button
              onClick={() => setActiveTab('settings')}
              className={`px-2 sm:px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center space-x-1 transition-all cursor-pointer ${
                activeTab === 'settings'
                  ? 'bg-cyan-500/20 text-cyan-200 border border-cyan-500/40'
                  : 'bg-[#11162B] text-indigo-200 hover:text-white border border-indigo-900/50'
              }`}
            >
              <span>🔑</span>
              <span className="hidden sm:inline">AI Accounts & Keys</span>
              <span className="sm:hidden text-[11px] font-bold">AI Keys</span>
            </button>

            <button
              onClick={() => setActiveTab('accounts')}
              className={`hidden sm:flex px-3 py-1.5 rounded-xl text-xs font-semibold items-center space-x-1.5 transition-all cursor-pointer ${
                activeTab === 'accounts'
                  ? 'bg-cyan-500/20 text-cyan-200 border border-cyan-500/40'
                  : 'bg-[#11162B] text-indigo-200 hover:text-white border border-indigo-900/50'
              }`}
            >
              <span>🌐</span>
              <span>Social Channels</span>
            </button>
          </div>
        )}

        <div className="hidden sm:flex items-center space-x-2 px-3 py-1.5 bg-cyan-500/10 border border-cyan-500/20 rounded-xl text-xs text-cyan-300">
          <div className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
          <span className="font-medium">Cosmic Core Active</span>
        </div>

        <button
          onClick={onQuickCreate}
          className="flex items-center space-x-2 bg-gradient-to-r from-cyan-500 via-indigo-600 to-fuchsia-600 hover:from-cyan-400 hover:to-fuchsia-500 text-white px-4 py-2 rounded-xl text-sm font-semibold shadow-lg shadow-cyan-500/20 transition-all active:scale-95 cursor-pointer"
        >
          <Rocket className="w-4 h-4 text-cyan-200" />
          <span>Launch AI Video</span>
        </button>
      </div>
    </header>
  );
};
